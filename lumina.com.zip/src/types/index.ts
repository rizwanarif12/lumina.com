export interface Product {
  _id: string;
  title: string;
  subtitle: string;
  description: string;
  price: number;
  compareAtPrice?: number;
  category: string;
  stock: number;
  rating: number;
  reviewCount: number;
  images: string[];
  tags: string[];
  featured?: boolean;
  specs?: Record<string, string>;
  createdAt: string;
  updatedAt?: string;
}

export interface User {
  _id: string;
  name: string;
  email: string;
  role: 'customer' | 'admin';
  address?: Address;
  createdAt: string;
}

export interface Address {
  fullName: string;
  street: string;
  city: string;
  state: string;
  postalCode: string;
  country: string;
  phone: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
  selectedVariant?: string;
}

export interface CartTotals {
  subtotal: number;
  tax: number;
  shipping: number;
  discount: number;
  total: number;
  freeShippingQualified: boolean;
  amountNeededForFreeShipping: number;
}

export interface Order {
  _id: string;
  orderNumber: string;
  userId: string;
  customer: {
    name: string;
    email: string;
  };
  items: CartItem[];
  shippingAddress: Address;
  shippingMethod: 'standard' | 'express';
  paymentMethod: 'card' | 'cod';
  paymentStatus: 'paid' | 'pending';
  pricing: CartTotals;
  status: 'confirmed' | 'processing' | 'shipped' | 'delivered';
  createdAt: string;
}

export interface AuthResponse {
  user: User;
  token: string;
}

export interface ApiResponse<T = unknown> {
  success: boolean;
  data?: T;
  message?: string;
  error?: string;
  total?: number;
  page?: number;
  totalPages?: number;
  limit?: number;
}
