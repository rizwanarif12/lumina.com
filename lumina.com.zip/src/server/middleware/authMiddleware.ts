import type { Request, Response, NextFunction } from 'express';
import { db } from '../db/mongoClient.ts';
import type { User } from '../../types/index.ts';

export interface AuthenticatedRequest extends Request {
  user?: User;
}

// In-memory session token store mapping token to userId
const tokenStore = new Map<string, string>();

export function generateAuthToken(userId: string): string {
  const token = `lum_${Buffer.from(userId + ':' + Date.now()).toString('base64')}`;
  tokenStore.set(token, userId);
  return token;
}

export function revokeToken(token: string): void {
  tokenStore.delete(token);
}

export async function requireAuth(req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    res.status(401).json({ success: false, error: 'Authentication required. Please log in.' });
    return;
  }

  const token = authHeader.substring(7).trim();
  const userId = tokenStore.get(token);

  if (!userId) {
    // Also support fallback decode for stateless resilience
    try {
      if (token.startsWith('lum_')) {
        const decoded = Buffer.from(token.substring(4), 'base64').toString('utf-8');
        const [extractedId] = decoded.split(':');
        if (extractedId) {
          const user = await db.users.findById(extractedId);
          if (user) {
            tokenStore.set(token, user._id);
            req.user = user;
            next();
            return;
          }
        }
      }
    } catch {
      // ignore
    }

    res.status(401).json({ success: false, error: 'Invalid or expired session. Please log in again.' });
    return;
  }

  const user = await db.users.findById(userId);
  if (!user) {
    res.status(401).json({ success: false, error: 'User record not found.' });
    return;
  }

  req.user = user;
  next();
}

export async function requireAdmin(req: AuthenticatedRequest, res: Response, next: NextFunction): Promise<void> {
  await requireAuth(req, res, () => {
    if (!req.user || req.user.role !== 'admin') {
      res.status(403).json({ success: false, error: 'Admin privileges required to perform this action.' });
      return;
    }
    next();
  });
}
