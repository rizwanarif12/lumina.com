import fs from 'node:fs';
import path from 'node:path';
import type { Product, User, Order } from '../../types/index.ts';

// Clean MongoDB-compatible ObjectId generator
export function generateObjectId(seedNumber?: number): string {
  if (seedNumber !== undefined) {
    const hex = seedNumber.toString(16).padStart(24, '0');
    return `6715f${hex.slice(5)}`;
  }
  const timestamp = Math.floor(Date.now() / 1000).toString(16).padStart(8, '0');
  const machine = Math.floor(Math.random() * 0xffffff).toString(16).padStart(6, '0');
  const pid = Math.floor(Math.random() * 0xffff).toString(16).padStart(4, '0');
  const counter = Math.floor(Math.random() * 0xffffff).toString(16).padStart(6, '0');
  return `${timestamp}${machine}${pid}${counter}`;
}

export type QueryFilter<T> = {
  [K in keyof T]?: any;
} & {
  $text?: { $search: string };
  $or?: Array<Record<string, any>>;
  [key: string]: any;
};

export class MongoCollection<T extends { _id: string }> {
  private name: string;
  private documents: Map<string, T> = new Map();
  private onPersist?: () => void;

  constructor(name: string, initialDocs: T[] = [], onPersist?: () => void) {
    this.name = name;
    this.onPersist = onPersist;
    for (const doc of initialDocs) {
      this.documents.set(doc._id, { ...doc });
    }
  }

  getCollectionName(): string {
    return this.name;
  }

  getAll(): T[] {
    return Array.from(this.documents.values()).map(doc => ({ ...doc }));
  }

  private matchesQuery(doc: any, filter: Record<string, any>): boolean {
    for (const [key, expected] of Object.entries(filter)) {
      if (key === '$text' && expected && typeof expected.$search === 'string') {
        const queryTerm = expected.$search.toLowerCase();
        const searchable = Object.values(doc)
          .filter(v => typeof v === 'string')
          .join(' ')
          .toLowerCase();
        if (!searchable.includes(queryTerm)) return false;
        continue;
      }

      if (key === '$or' && Array.isArray(expected)) {
        const matchedOr = expected.some(subFilter => this.matchesQuery(doc, subFilter));
        if (!matchedOr) return false;
        continue;
      }

      const docVal = doc[key];

      if (expected && typeof expected === 'object' && !Array.isArray(expected)) {
        if ('$in' in expected && Array.isArray(expected.$in)) {
          if (!expected.$in.includes(docVal)) return false;
        }
        if ('$gte' in expected && typeof expected.$gte === 'number') {
          if (typeof docVal !== 'number' || docVal < expected.$gte) return false;
        }
        if ('$lte' in expected && typeof expected.$lte === 'number') {
          if (typeof docVal !== 'number' || docVal > expected.$lte) return false;
        }
        if ('$ne' in expected) {
          if (docVal === expected.$ne) return false;
        }
        if ('$regex' in expected) {
          const regex = new RegExp(expected.$regex, expected.$options || 'i');
          if (typeof docVal !== 'string' || !regex.test(docVal)) return false;
        }
        continue;
      }

      if (docVal !== expected) {
        return false;
      }
    }
    return true;
  }

  async find(
    filter: QueryFilter<T> = {},
    options: { sort?: Record<string, 1 | -1>; limit?: number; skip?: number } = {}
  ): Promise<T[]> {
    let results = this.getAll().filter(doc => this.matchesQuery(doc, filter));

    if (options.sort) {
      const [field, direction] = Object.entries(options.sort)[0];
      results.sort((a: any, b: any) => {
        if (a[field] < b[field]) return direction === 1 ? -1 : 1;
        if (a[field] > b[field]) return direction === 1 ? 1 : -1;
        return 0;
      });
    }

    if (options.skip) {
      results = results.slice(options.skip);
    }
    if (options.limit) {
      results = results.slice(0, options.limit);
    }

    return results;
  }

  async count(filter: QueryFilter<T> = {}): Promise<number> {
    return this.getAll().filter(doc => this.matchesQuery(doc, filter)).length;
  }

  async findOne(filter: QueryFilter<T>): Promise<T | null> {
    const list = await this.find(filter, { limit: 1 });
    return list.length > 0 ? list[0] : null;
  }

  async findById(id: string): Promise<T | null> {
    const item = this.documents.get(id);
    return item ? { ...item } : null;
  }

  async insertOne(doc: Omit<T, '_id'> & { _id?: string }): Promise<T> {
    const _id = doc._id || generateObjectId();
    const newDoc = { ...doc, _id } as T;
    this.documents.set(_id, newDoc);
    if (this.onPersist) this.onPersist();
    return { ...newDoc };
  }

  async updateOne(
    filter: QueryFilter<T>,
    update: { $set?: Partial<T>; $inc?: Record<string, number> }
  ): Promise<boolean> {
    const target = await this.findOne(filter);
    if (!target) return false;

    const updated = { ...target };
    if (update.$set) {
      Object.assign(updated, update.$set);
    }
    if (update.$inc) {
      for (const [k, v] of Object.entries(update.$inc)) {
        (updated as any)[k] = ((updated as any)[k] || 0) + v;
      }
    }

    this.documents.set(target._id, updated);
    if (this.onPersist) this.onPersist();
    return true;
  }

  async deleteOne(filter: QueryFilter<T>): Promise<boolean> {
    const target = await this.findOne(filter);
    if (!target) return false;
    this.documents.delete(target._id);
    if (this.onPersist) this.onPersist();
    return true;
  }

  async countDocuments(filter: QueryFilter<T> = {}): Promise<number> {
    return this.count(filter);
  }
}

// ---------------------------------------------------------------------
// Algorithmic 1,000-Item Catalog Seeder for Handmade Bags, Trolley Luggage & Antique Artistry
// ---------------------------------------------------------------------
function generate1000ArtisanProducts(): Product[] {
  const products: Product[] = [];

  // Dedicated flagship assets
  const localTrolley = '/src/assets/images/artisan_trolley_luggage_1792528198811.jpg';
  const localAntique = '/src/assets/images/antique_artistry_artifact_1792528199505.jpg';
  const localBag = '/src/assets/images/lumina_leather_tote_1792496777297.jpg';
  const localVessel = '/src/assets/images/lumina_ceramic_vessel_1792496777360.jpg';

  // Rich themed imagery pools
  const bagImages = [
    localBag,
    'https://images.unsplash.com/photo-1548036328-c9fa89d128fa?w=800&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1590874103328-eac38a683ce7?w=800&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1566150905458-1bf1fc113f0d?w=800&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1622560480605-d83c853bc5c3?w=800&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1598532163257-ae3c6b2524b6?w=800&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1584917865442-de89df76afd3?w=800&auto=format&fit=crop&q=80',
  ];

  const trolleyImages = [
    localTrolley,
    'https://images.unsplash.com/photo-1565026057447-bc90a3dceb87?w=800&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1581553680321-4fffae59fccd?w=800&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=800&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1544816155-12df9643f363?w=800&auto=format&fit=crop&q=80',
  ];

  const antiqueImages = [
    localAntique,
    localVessel,
    'https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?w=800&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1582561424760-0321d75e81fa?w=800&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1533158307587-828f0a76ef46?w=800&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?w=800&auto=format&fit=crop&q=80',
    'https://images.unsplash.com/photo-1513519245088-0e12902e5a38?w=800&auto=format&fit=crop&q=80',
  ];

  // 1. Handmade Bags templates (380 items)
  const bagStyles = [
    { type: 'Tuscan Leather Tote', basePrice: 220, sub: 'Full-Grain Vegetable-Tanned Vachetta', material: 'Vachetta Italian Cowhide' },
    { type: 'Bohemian Embroidered Saddle Bag', basePrice: 165, sub: 'Hand-Stitched Silk Thread & Vegetable Dyes', material: 'Organic Cotton Canvas & Raw Calfskin' },
    { type: 'Artisanal Waxed Canvas Messenger', basePrice: 185, sub: 'Water-Resistant Scottish Oilcloth & Brass Rivets', material: '18oz Heavy Waxed Duck Canvas' },
    { type: 'Woven Raffia Market Basket Bag', basePrice: 110, sub: 'Hand-braided Natural Palm Leaf & Leather Handles', material: 'Sustainable Wild Madagascar Raffia' },
    { type: 'Vintage Postal Satchel', basePrice: 260, sub: 'Hand-burnished English Bridle Leather', material: 'Vegetable-Tanned Bridle Hide' },
    { type: 'Macramé Knotted Hobo Bag', basePrice: 140, sub: 'Artisan Knotted Linen Cord with Horn Toggle', material: 'Belgian Linen & Reclaimed Horn' },
    { type: 'Suede Patchwork Slouch Bag', basePrice: 195, sub: 'Hand-Cut Velour Suede & Saddle Stitching', material: 'Italian Calf Suede' },
    { type: 'Artisan Weekender Duffel', basePrice: 340, sub: 'Double-Reinforced Base & Antique Brass Latches', material: 'Heavy Tumbled Buffalo Leather' },
    { type: 'Hand-tooled Floral Crossbody', basePrice: 175, sub: 'Relief-Carved Leather with Antique Patina', material: 'Full-Grain Tooling Leather' },
    { type: 'Minimalist Raw-Edge Backpack', basePrice: 290, sub: 'Seamless Fold Architecture & Copper Rivets', material: 'Oil-Pullup Top Grain Cowhide' },
  ];

  const origins = [
    'Florence, Italy', 'Marrakech, Morocco', 'Oaxaca, Mexico', 'Kyoto, Japan', 'Jodhpur, India',
    'Córdoba, Spain', 'Cusco, Peru', 'Istanbul, Turkey', 'Vienna, Austria', 'Antwerp, Belgium'
  ];

  const adjectives = [
    'Heirloom', 'Handcrafted', 'Signature', 'Artisan', 'Vintage-Treated',
    'Distressed', 'Master-Carved', 'Limited Studio', 'Collector’s', 'Classic',
    'Custom-Fitted', 'Authentic', 'Rare-Find', 'Restored', 'Heritage'
  ];

  // Generate 380 Handmade Bags
  for (let i = 1; i <= 380; i++) {
    const style = bagStyles[i % bagStyles.length];
    const origin = origins[i % origins.length];
    const adj = adjectives[i % adjectives.length];
    const priceVariance = (i * 7) % 85;
    const price = style.basePrice + priceVariance;
    const compareAt = price > 200 ? price + 50 : undefined;
    const stock = (i % 18) + 1;
    const rating = Number((4.6 + ((i % 5) * 0.1)).toFixed(1));
    const reviews = 12 + ((i * 13) % 75);

    products.push({
      _id: generateObjectId(1000 + i),
      title: `${adj} ${style.type} No. ${String(i).padStart(3, '0')}`,
      subtitle: `${style.sub} · ${origin}`,
      description: `Meticulously handcrafted in our partner atelier in ${origin}. Crafted from ${style.material} using heritage saddle-stitching techniques that ensure lifetime durability and develop a deep natural patina over years of use.`,
      price,
      compareAtPrice: compareAt,
      category: 'Handmade Bags',
      stock,
      rating,
      reviewCount: reviews,
      images: [bagImages[i % bagImages.length]],
      tags: ['Handcrafted', 'Artisan Leather', 'Natural Patina', origin.split(',')[0]],
      featured: i <= 3,
      specs: {
        'Material': style.material,
        'Artisan Studio': origin,
        'Hardware': 'Solid Antique Cast Brass',
        'Stitching': 'Waxed Irish Linen Hand Saddle Stitch',
        'Dimensions': `${30 + (i % 15)}cm x ${22 + (i % 10)}cm x ${10 + (i % 8)}cm`,
      },
      createdAt: new Date(Date.now() - i * 86400000).toISOString(),
    });
  }

  // 2. Trolley Bags & Travel Luggage templates (310 items)
  const trolleyStyles = [
    { type: 'Artisan Vachetta Rolling Trunk', basePrice: 580, sub: 'Solid Brass Corners & Silent Hinomoto Wheels', material: '4mm Thick Italian Saddle Leather' },
    { type: 'Heritage Steamer Trolley Suitcase', basePrice: 640, sub: 'Reinforced Vulcanized Fiberboard & Hand-Nailed Studs', material: 'Vulcanized Fiberboard & Raw Cowhide' },
    { type: 'Vintage Aviator Pilot Wheeled Case', basePrice: 490, sub: 'Double Telescopic Brass Handle & TSA Padlock', material: 'Hand-Buffed Waxed Hide' },
    { type: 'Artisanal Canvas & Leather Cabin Spinner', basePrice: 380, sub: '360° Ball-Bearing Wheels & Italian Tan Trim', material: '22oz Military Grade Cotton Duck & Full-Grain Trim' },
    { type: 'Handcrafted Safari Roller Duffle', basePrice: 420, sub: 'Dual Wheel Off-Road Tread & Waterproof Lining', material: 'Tumbled Tuscan Kip Leather' },
    { type: 'Antique Brass Bound Garment Trolley', basePrice: 720, sub: 'Internal Cedar Hanger Bar & Linen Compartments', material: 'Hand-Milled Brass & Vegetable Vachetta' },
    { type: 'Compact Executive Overnight Trolley', basePrice: 340, sub: 'Padded 16" Laptop Chamber & USB Cable Port', material: 'Aniline Cowhide Leather' },
    { type: 'Transcontinental Grand Voyage Trunk', basePrice: 890, sub: 'Museum Replica Trunk with Monogrammed Brass Plate', material: 'Solid Poplar Framework & Heavy Bridle Leather' },
  ];

  // Generate 310 Trolley Bags
  for (let i = 1; i <= 310; i++) {
    const style = trolleyStyles[i % trolleyStyles.length];
    const origin = origins[(i + 3) % origins.length];
    const adj = adjectives[(i + 5) % adjectives.length];
    const priceVariance = (i * 11) % 180;
    const price = style.basePrice + priceVariance;
    const compareAt = price + 80;
    const stock = (i % 10) + 1;
    const rating = Number((4.7 + ((i % 4) * 0.1)).toFixed(1));
    const reviews = 8 + ((i * 17) % 60);

    products.push({
      _id: generateObjectId(2000 + i),
      title: `${adj} ${style.type} Ed. ${String(i).padStart(3, '0')}`,
      subtitle: `${style.sub} · ${origin}`,
      description: `Engineered for the discerning voyager, this handcrafted trolley marries heirloom aesthetics with contemporary travel reliability. Built with ${style.material}, aircraft-grade structural framework, silent Japanese wheels, and solid brass fittings.`,
      price,
      compareAtPrice: compareAt,
      category: 'Trolley Bags & Travel',
      stock,
      rating,
      reviewCount: reviews,
      images: [trolleyImages[i % trolleyImages.length]],
      tags: ['Trolley Bag', 'Luggage', 'Voyage', 'Solid Brass', 'Hinomoto Wheels'],
      featured: i <= 3,
      specs: {
        'Chassis': 'Lightweight Aluminium & Hardwood Core',
        'Exterior Shell': style.material,
        'Wheel System': 'Ultra-Quiet 360° Hinomoto Japanese Spinners',
        'Locks': 'Dual Heavy Brass Tumbler Padlocks',
        'Capacity': `${38 + (i % 30)} Liters (ICAO Cabin Approved)`,
        'Origin': origin,
      },
      createdAt: new Date(Date.now() - (i + 400) * 86400000).toISOString(),
    });
  }

  // 3. Antique Artistry & Artisan Artifacts (310 items)
  const antiqueStyles = [
    { type: 'Engraved Celestial Brass Astrolabe', basePrice: 420, sub: 'Hand-Chiseled 18th Century Islamic Navigational Relic', material: 'Cast & Hand-Chiseled C360 Brass' },
    { type: 'Handmade Bone-Inlay Keepsake Casket', basePrice: 280, sub: 'Ethical Camel Bone & Solid Sheesham Hardwood', material: 'Sheesham Wood & Hand-Cut Camel Bone' },
    { type: 'Repoussé Hammered Copper Ritual Urn', basePrice: 195, sub: 'Volcanic Oxidation Patina & Floral Filigree', material: '99.9% Pure Hand-Beaten Copper' },
    { type: 'Antique Ottoman Damascene Steel Box', basePrice: 350, sub: '24k Gold Wire Inlay on Forged Pattern Steel', material: 'Forged Wootz Steel & 24k Gold Foil' },
    { type: 'Hand-Carved Sacred Teak Wood Relic', basePrice: 240, sub: 'Reclaimed 19th Century Temple Architectural Panel', material: 'Century-Old Seasoned Teak Hardwood' },
    { type: 'Antique Vitreous Terracotta Amphora', basePrice: 160, sub: 'Subterranean Excavation Glaze & Clay Mineral Body', material: 'High-Fire Earthenware Terracotta' },
    { type: 'Moroccan Hand-Chiseled Brass Lantern', basePrice: 210, sub: 'Geometric Shadow Cast Glass & Pierced Metalwork', material: 'Antiqued Sheet Brass & Stained Glass' },
    { type: 'Venetian Blown Glass & Gilded Reliquary', basePrice: 480, sub: 'Hand-Blown Murano Millefiori with Gold Leaf Accents', material: 'Murano Glass & Hand-Applied 22k Leaf' },
  ];

  // Generate 310 Antique Artistry items
  for (let i = 1; i <= 310; i++) {
    const style = antiqueStyles[i % antiqueStyles.length];
    const origin = origins[(i + 7) % origins.length];
    const adj = adjectives[(i + 9) % adjectives.length];
    const priceVariance = (i * 13) % 220;
    const price = style.basePrice + priceVariance;
    const compareAt = price > 300 ? price + 110 : undefined;
    const stock = (i % 5) + 1; // antiques are rare/low stock
    const rating = Number((4.8 + ((i % 3) * 0.1)).toFixed(1));
    const reviews = 6 + ((i * 9) % 45);

    products.push({
      _id: generateObjectId(3000 + i),
      title: `${adj} ${style.type} Ref. ${String(i).padStart(3, '0')}`,
      subtitle: `${style.sub} · Curated in ${origin}`,
      description: `A singular collectible artifact representing centuries of artisanal virtuosity. Sourced and authenticated in ${origin}. Composed of ${style.material}, each piece features distinctive hand-worked imperfections, archival marks, and historic patina.`,
      price,
      compareAtPrice: compareAt,
      category: 'Antique Artistry & Artifacts',
      stock,
      rating,
      reviewCount: reviews,
      images: [antiqueImages[i % antiqueImages.length]],
      tags: ['Antique', 'One-of-a-Kind', 'Museum Quality', 'Hand-Carved', origin.split(',')[0]],
      featured: i <= 3,
      specs: {
        'Historical Medium': style.material,
        'Estimated Era': `Late 18th to Early 20th Century`,
        'Provenance': `Authenticated in ${origin}`,
        'Condition': 'Preserved Antique / Museum Restored',
        'Includes': 'Certificate of Handcrafted Provenance',
      },
      createdAt: new Date(Date.now() - (i + 800) * 86400000).toISOString(),
    });
  }

  // Total products = 380 + 310 + 310 = 1000 items!
  return products;
}

export class LuminaDatabase {
  public users: MongoCollection<User & { passwordHash?: string }>;
  public products: MongoCollection<Product>;
  public orders: MongoCollection<Order>;
  private dataDir = path.resolve(process.cwd(), 'data');
  private dbFile = path.resolve(this.dataDir, 'db_store.json');

  constructor() {
    const loaded = this.loadFromDisk();

    this.users = new MongoCollection('users', loaded?.users || defaultUsers, () => this.saveToDisk());

    // Ensure we have the full 1,000 item catalog
    const productList = (loaded?.products && loaded.products.length >= 950)
      ? loaded.products
      : generate1000ArtisanProducts();

    this.products = new MongoCollection('products', productList, () => this.saveToDisk());
    this.orders = new MongoCollection('orders', loaded?.orders || defaultOrders, () => this.saveToDisk());

    // Initial save to persist 1000 items
    if (!loaded || !loaded.products || loaded.products.length < 950) {
      this.saveToDisk();
    }
  }

  private loadFromDisk() {
    try {
      if (fs.existsSync(this.dbFile)) {
        const raw = fs.readFileSync(this.dbFile, 'utf-8');
        return JSON.parse(raw);
      }
    } catch {
      // ignore
    }
    return null;
  }

  private saveToDisk() {
    try {
      if (!fs.existsSync(this.dataDir)) {
        fs.mkdirSync(this.dataDir, { recursive: true });
      }
      const data = {
        users: this.users.getAll(),
        products: this.products.getAll(),
        orders: this.orders.getAll(),
        totalProductsCount: this.products.getAll().length,
        lastUpdated: new Date().toISOString(),
      };
      fs.writeFileSync(this.dbFile, JSON.stringify(data, null, 2), 'utf-8');
    } catch {
      // In-memory fallback
    }
  }
}

// Initial seed users and orders
const defaultUsers: Array<User & { passwordHash: string }> = [
  {
    _id: '6715f001a1b2c3d4e5f60001',
    name: 'Marcus Vance',
    email: 'admin@lumina.dev',
    role: 'admin',
    passwordHash: 'AdminPassword123!',
    createdAt: '2026-01-15T10:00:00.000Z',
    address: {
      fullName: 'Marcus Vance',
      street: '420 Design Quarter Ave',
      city: 'San Francisco',
      state: 'CA',
      postalCode: '94107',
      country: 'United States',
      phone: '+1 (555) 234-5678',
    },
  },
  {
    _id: '6715f001a1b2c3d4e5f60002',
    name: 'Jane Doe',
    email: 'jane@example.com',
    role: 'customer',
    passwordHash: 'CustomerPass123!',
    createdAt: '2026-02-01T12:30:00.000Z',
    address: {
      fullName: 'Jane Doe',
      street: '742 Evergreen Terrace',
      city: 'Portland',
      state: 'OR',
      postalCode: '97201',
      country: 'United States',
      phone: '+1 (555) 987-6543',
    },
  },
];

const defaultOrders: Order[] = [
  {
    _id: '6715f201a1b2c3d4e5f60101',
    orderNumber: 'LUM-84920',
    userId: '6715f001a1b2c3d4e5f60002',
    customer: {
      name: 'Jane Doe',
      email: 'jane@example.com',
    },
    items: [
      {
        product: {
          _id: '6715f0000000000000001001',
          title: 'Heirloom Tuscan Leather Tote No. 001',
          subtitle: 'Full-Grain Vachetta Leather · Florence, Italy',
          description: 'Handcrafted in Florence atelier.',
          price: 245,
          category: 'Handmade Bags',
          stock: 12,
          rating: 4.9,
          reviewCount: 38,
          images: ['/src/assets/images/lumina_leather_tote_1792496777297.jpg'],
          tags: ['Handcrafted', 'Leather'],
          createdAt: '2026-01-10T08:00:00.000Z',
        },
        quantity: 1,
      },
    ],
    shippingAddress: {
      fullName: 'Jane Doe',
      street: '742 Evergreen Terrace',
      city: 'Portland',
      state: 'OR',
      postalCode: '97201',
      country: 'United States',
      phone: '+1 (555) 987-6543',
    },
    shippingMethod: 'standard',
    paymentMethod: 'card',
    paymentStatus: 'paid',
    pricing: {
      subtotal: 245,
      discount: 24.5,
      shipping: 0,
      tax: 18.74,
      total: 239.24,
      freeShippingQualified: true,
      amountNeededForFreeShipping: 0,
    },
    status: 'shipped',
    createdAt: '2026-02-14T10:15:00.000Z',
  },
];

export const db = new LuminaDatabase();
