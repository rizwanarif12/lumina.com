import express from 'express';
import { register, login, getProfile, updateProfile } from './controllers/authController.ts';
import {
  getProducts,
  getProductById,
  getCategories,
  createProduct,
  updateProduct,
  deleteProduct,
} from './controllers/productController.ts';
import {
  createOrder,
  getCustomerOrders,
  getAllOrders,
  updateOrderStatus,
} from './controllers/orderController.ts';
import { requireAuth, requireAdmin } from './middleware/authMiddleware.ts';

export const apiRouter = express.Router();

// Body parser
apiRouter.use(express.json());

// Health Check
apiRouter.get('/health', (req, res) => {
  res.json({
    status: 'online',
    timestamp: new Date().toISOString(),
    database: 'MongoDB NoSQL Document Store Connected',
  });
});

// Authentication Routes
apiRouter.post('/auth/register', register);
apiRouter.post('/auth/login', login);
apiRouter.get('/auth/me', requireAuth, getProfile);
apiRouter.put('/auth/profile', requireAuth, updateProfile);

// Product Catalog Routes
apiRouter.get('/products/categories', getCategories);
apiRouter.get('/products', getProducts);
apiRouter.get('/products/:id', getProductById);

// Admin Product Catalog Management
apiRouter.post('/admin/products', requireAdmin, createProduct);
apiRouter.put('/admin/products/:id', requireAdmin, updateProduct);
apiRouter.delete('/admin/products/:id', requireAdmin, deleteProduct);

// Orders & Checkout Routes
apiRouter.post('/orders', createOrder);
apiRouter.get('/orders/my', requireAuth, getCustomerOrders);

// Admin Order Management
apiRouter.get('/admin/orders', requireAdmin, getAllOrders);
apiRouter.patch('/admin/orders/:id/status', requireAdmin, updateOrderStatus);
