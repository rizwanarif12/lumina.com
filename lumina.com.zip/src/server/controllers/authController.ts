import type { Response } from 'express';
import { db } from '../db/mongoClient.ts';
import { generateAuthToken, type AuthenticatedRequest } from '../middleware/authMiddleware.ts';

export async function register(req: AuthenticatedRequest, res: Response): Promise<void> {
  try {
    const { name, email, password, role = 'customer' } = req.body;

    if (!name || !email || !password) {
      res.status(400).json({ success: false, error: 'Full name, email, and password are required.' });
      return;
    }

    const cleanEmail = String(email).trim().toLowerCase();
    if (!cleanEmail.includes('@') || cleanEmail.length < 5) {
      res.status(400).json({ success: false, error: 'Please provide a valid email address.' });
      return;
    }

    if (String(password).length < 6) {
      res.status(400).json({ success: false, error: 'Password must be at least 6 characters long.' });
      return;
    }

    const existing = await db.users.findOne({ email: cleanEmail });
    if (existing) {
      res.status(409).json({ success: false, error: 'An account with this email address already exists.' });
      return;
    }

    const newUser = await db.users.insertOne({
      name: String(name).trim(),
      email: cleanEmail,
      role: role === 'admin' ? 'admin' : 'customer',
      passwordHash: String(password),
      createdAt: new Date().toISOString(),
    });

    const token = generateAuthToken(newUser._id);
    const { passwordHash: _, ...safeUser } = newUser;

    res.status(201).json({
      success: true,
      data: {
        user: safeUser,
        token,
      },
      message: 'Account successfully created.',
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message || 'Registration failed.' });
  }
}

export async function login(req: AuthenticatedRequest, res: Response): Promise<void> {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      res.status(400).json({ success: false, error: 'Email and password are required.' });
      return;
    }

    const cleanEmail = String(email).trim().toLowerCase();
    const user = await db.users.findOne({ email: cleanEmail });

    if (!user || user.passwordHash !== String(password)) {
      res.status(401).json({ success: false, error: 'Invalid email or password combination.' });
      return;
    }

    const token = generateAuthToken(user._id);
    const { passwordHash: _, ...safeUser } = user;

    res.status(200).json({
      success: true,
      data: {
        user: safeUser,
        token,
      },
      message: 'Signed in successfully.',
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message || 'Login failed.' });
  }
}

export async function getProfile(req: AuthenticatedRequest, res: Response): Promise<void> {
  if (!req.user) {
    res.status(401).json({ success: false, error: 'Unauthorized.' });
    return;
  }
  const { passwordHash: _, ...safeUser } = req.user as any;
  res.status(200).json({ success: true, data: safeUser });
}

export async function updateProfile(req: AuthenticatedRequest, res: Response): Promise<void> {
  if (!req.user) {
    res.status(401).json({ success: false, error: 'Unauthorized.' });
    return;
  }

  const { name, address } = req.body;
  const updates: any = {};
  if (name) updates.name = String(name).trim();
  if (address) updates.address = address;

  await db.users.updateOne({ _id: req.user._id }, { $set: updates });
  const updatedUser = await db.users.findById(req.user._id);
  const { passwordHash: _, ...safeUser } = updatedUser as any;

  res.status(200).json({ success: true, data: safeUser, message: 'Profile updated.' });
}
