import type { Request, Response } from 'express';
import { db } from '../db/mongoClient.ts';
import type { Product } from '../../types/index.ts';

export async function getProducts(req: Request, res: Response): Promise<void> {
  try {
    const { category, search, minPrice, maxPrice, sort, featured, page = '1', limit = '24' } = req.query;

    const pageNum = Math.max(1, parseInt(String(page), 10) || 1);
    const limitNum = Math.min(100, Math.max(1, parseInt(String(limit), 10) || 24));

    const filter: Record<string, any> = {};

    if (category && category !== 'All') {
      filter.category = String(category);
    }

    if (featured === 'true') {
      filter.featured = true;
    }

    if (minPrice || maxPrice) {
      filter.price = {};
      if (minPrice) filter.price.$gte = Number(minPrice);
      if (maxPrice) filter.price.$lte = Number(maxPrice);
    }

    let sortOption: Record<string, 1 | -1> | undefined;
    if (sort === 'price_asc') sortOption = { price: 1 };
    else if (sort === 'price_desc') sortOption = { price: -1 };
    else if (sort === 'rating') sortOption = { rating: -1 };
    else if (sort === 'newest') sortOption = { createdAt: -1 };

    let allFiltered = await db.products.find(filter, { sort: sortOption });

    if (search && typeof search === 'string' && search.trim().length > 0) {
      const q = search.trim().toLowerCase();
      allFiltered = allFiltered.filter(p =>
        p.title.toLowerCase().includes(q) ||
        p.subtitle.toLowerCase().includes(q) ||
        p.description.toLowerCase().includes(q) ||
        p.category.toLowerCase().includes(q) ||
        p.tags.some(t => t.toLowerCase().includes(q))
      );
    }

    const total = allFiltered.length;
    const totalPages = Math.ceil(total / limitNum);
    const skip = (pageNum - 1) * limitNum;
    const paginatedProducts = allFiltered.slice(skip, skip + limitNum);

    res.status(200).json({
      success: true,
      data: paginatedProducts,
      total,
      page: pageNum,
      totalPages,
      limit: limitNum,
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message || 'Failed to fetch products' });
  }
}

export async function getProductById(req: Request, res: Response): Promise<void> {
  try {
    const { id } = req.params;
    const product = await db.products.findById(id);

    if (!product) {
      res.status(404).json({ success: false, error: 'Product not found' });
      return;
    }

    res.status(200).json({ success: true, data: product });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message || 'Failed to fetch product' });
  }
}

export async function getCategories(req: Request, res: Response): Promise<void> {
  try {
    const all = await db.products.find();
    const categoriesMap: Record<string, number> = {};

    for (const p of all) {
      categoriesMap[p.category] = (categoriesMap[p.category] || 0) + 1;
    }

    const categories = Object.entries(categoriesMap).map(([name, count]) => ({
      name,
      count,
    }));

    res.status(200).json({
      success: true,
      data: [{ name: 'All Items', count: all.length }, ...categories],
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
}

export async function createProduct(req: Request, res: Response): Promise<void> {
  try {
    const {
      title,
      subtitle,
      description,
      price,
      compareAtPrice,
      category,
      stock,
      images,
      tags,
      featured,
      specs,
    } = req.body;

    if (!title || price === undefined || !category || stock === undefined) {
      res.status(400).json({
        success: false,
        error: 'Title, category, price, and stock are required fields.',
      });
      return;
    }

    const newProduct = await db.products.insertOne({
      title: String(title).trim(),
      subtitle: subtitle ? String(subtitle).trim() : '',
      description: description ? String(description).trim() : '',
      price: Number(price),
      compareAtPrice: compareAtPrice ? Number(compareAtPrice) : undefined,
      category: String(category).trim(),
      stock: Math.max(0, parseInt(stock, 10)),
      rating: 5.0,
      reviewCount: 1,
      images: Array.isArray(images) && images.length > 0
        ? images
        : ['/src/assets/images/lumina_leather_tote_1792496777297.jpg'],
      tags: Array.isArray(tags) ? tags : ['Handcrafted', 'Heirloom'],
      featured: Boolean(featured),
      specs: specs || {},
      createdAt: new Date().toISOString(),
    });

    res.status(201).json({
      success: true,
      data: newProduct,
      message: 'Product created successfully in catalog.',
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message || 'Failed to create product' });
  }
}

export async function updateProduct(req: Request, res: Response): Promise<void> {
  try {
    const { id } = req.params;
    const existing = await db.products.findById(id);

    if (!existing) {
      res.status(404).json({ success: false, error: 'Product not found' });
      return;
    }

    const updates: Partial<Product> = {};
    const allowed = ['title', 'subtitle', 'description', 'price', 'compareAtPrice', 'category', 'stock', 'images', 'tags', 'featured', 'specs'];

    for (const key of allowed) {
      if (req.body[key] !== undefined) {
        if (key === 'price' || key === 'compareAtPrice') {
          (updates as any)[key] = req.body[key] !== null ? Number(req.body[key]) : undefined;
        } else if (key === 'stock') {
          (updates as any)[key] = Math.max(0, parseInt(req.body[key], 10));
        } else {
          (updates as any)[key] = req.body[key];
        }
      }
    }
    updates.updatedAt = new Date().toISOString();

    await db.products.updateOne({ _id: id }, { $set: updates });
    const updated = await db.products.findById(id);

    res.status(200).json({
      success: true,
      data: updated,
      message: 'Product catalog updated successfully.',
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message || 'Failed to update product' });
  }
}

export async function deleteProduct(req: Request, res: Response): Promise<void> {
  try {
    const { id } = req.params;
    const existing = await db.products.findById(id);

    if (!existing) {
      res.status(404).json({ success: false, error: 'Product not found' });
      return;
    }

    await db.products.deleteOne({ _id: id });

    res.status(200).json({
      success: true,
      message: `Product "${existing.title}" deleted from catalog.`,
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message || 'Failed to delete product' });
  }
}
