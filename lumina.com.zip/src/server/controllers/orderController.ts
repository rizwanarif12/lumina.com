import type { Response } from 'express';
import { db } from '../db/mongoClient.ts';
import type { AuthenticatedRequest } from '../middleware/authMiddleware.ts';
import { calculateCartTotals, validateInventory } from '../../utils/calculations.ts';
import type { Order, CartItem, Address } from '../../types/index.ts';

export async function createOrder(req: AuthenticatedRequest, res: Response): Promise<void> {
  try {
    const {
      items,
      shippingAddress,
      shippingMethod = 'standard',
      paymentMethod = 'card',
      promoCode,
      customerNotes,
    } = req.body;

    if (!items || !Array.isArray(items) || items.length === 0) {
      res.status(400).json({ success: false, error: 'Cannot create order with an empty cart.' });
      return;
    }

    if (!shippingAddress || !shippingAddress.fullName || !shippingAddress.street || !shippingAddress.city || !shippingAddress.postalCode) {
      res.status(400).json({
        success: false,
        error: 'Complete shipping address (Full Name, Street, City, and Postal Code) is required.',
      });
      return;
    }

    // Server-side inventory and price verification from MongoDB database
    const verifiedItems: CartItem[] = [];
    for (const item of items) {
      const productId = item.product?._id || item.productId;
      const product = await db.products.findById(productId);

      if (!product) {
        res.status(404).json({
          success: false,
          error: `Product with ID ${productId} is no longer available in the catalog.`,
        });
        return;
      }

      const requestedQty = Math.max(1, parseInt(item.quantity, 10) || 1);
      const inventoryCheck = validateInventory(product.stock, requestedQty);

      if (!inventoryCheck.valid) {
        res.status(409).json({
          success: false,
          error: `Insufficient stock for "${product.title}". ${inventoryCheck.message}`,
        });
        return;
      }

      verifiedItems.push({
        product,
        quantity: requestedQty,
        selectedVariant: item.selectedVariant,
      });
    }

    // Recalculate totals authoritatively on server
    const pricingItems = verifiedItems.map(i => ({
      price: i.product.price,
      quantity: i.quantity,
    }));

    const pricing = calculateCartTotals(pricingItems, shippingMethod, promoCode);

    // Decrement stock in MongoDB collection
    for (const item of verifiedItems) {
      await db.products.updateOne(
        { _id: item.product._id },
        { $inc: { stock: -item.quantity } }
      );
    }

    // Generate unique human-readable order number
    const randomSuffix = Math.floor(10000 + Math.random() * 90000);
    const orderNumber = `LUM-${randomSuffix}`;

    const userId = req.user ? req.user._id : 'guest_' + Date.now();
    const customer = {
      name: req.user ? req.user.name : shippingAddress.fullName,
      email: req.user ? req.user.email : shippingAddress.email || 'customer@lumina.dev',
    };

    const newOrder: Omit<Order, '_id'> = {
      orderNumber,
      userId,
      customer,
      items: verifiedItems,
      shippingAddress: shippingAddress as Address,
      shippingMethod,
      paymentMethod,
      paymentStatus: paymentMethod === 'card' ? 'paid' : 'pending',
      pricing,
      status: 'confirmed',
      createdAt: new Date().toISOString(),
    };

    const created = await db.orders.insertOne(newOrder);

    res.status(201).json({
      success: true,
      data: created,
      message: `Order #${orderNumber} placed successfully.`,
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message || 'Failed to place order.' });
  }
}

export async function getCustomerOrders(req: AuthenticatedRequest, res: Response): Promise<void> {
  try {
    if (!req.user) {
      res.status(401).json({ success: false, error: 'Please log in to view your order history.' });
      return;
    }

    const orders = await db.orders.find(
      { userId: req.user._id },
      { sort: { createdAt: -1 } }
    );

    res.status(200).json({ success: true, data: orders });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
}

export async function getAllOrders(req: AuthenticatedRequest, res: Response): Promise<void> {
  try {
    const orders = await db.orders.find({}, { sort: { createdAt: -1 } });
    res.status(200).json({ success: true, data: orders, count: orders.length });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
}

export async function updateOrderStatus(req: AuthenticatedRequest, res: Response): Promise<void> {
  try {
    const { id } = req.params;
    const { status } = req.body;

    const validStatuses = ['confirmed', 'processing', 'shipped', 'delivered'];
    if (!validStatuses.includes(status)) {
      res.status(400).json({ success: false, error: `Invalid status. Must be one of: ${validStatuses.join(', ')}` });
      return;
    }

    const order = await db.orders.findById(id);
    if (!order) {
      res.status(404).json({ success: false, error: 'Order not found.' });
      return;
    }

    await db.orders.updateOne({ _id: id }, { $set: { status } });
    const updated = await db.orders.findById(id);

    res.status(200).json({ success: true, data: updated, message: `Order status updated to ${status}.` });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
}
