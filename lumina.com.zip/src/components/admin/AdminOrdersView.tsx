import React, { useState, useEffect } from 'react';
import { Truck, CheckCircle2, Clock, RefreshCw, ShoppingCart, UserCheck } from 'lucide-react';
import type { Order } from '../../types/index.ts';
import { api } from '../../api/client.ts';
import { useNotification } from '../../context/NotificationContext.tsx';

export const AdminOrdersView: React.FC = () => {
  const [orders, setOrders] = useState<Order[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const { success, error } = useNotification();

  const fetchOrders = async () => {
    try {
      setIsLoading(true);
      const res = await api.getAllOrders();
      if (res.success && res.data) {
        setOrders(res.data);
      }
    } catch (err: any) {
      error('Failed to load orders', err.message);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchOrders();
  }, []);

  const handleStatusChange = async (orderId: string, newStatus: string) => {
    try {
      await api.updateOrderStatus(orderId, newStatus);
      success('Order Updated', `Status changed to ${newStatus}`);
      fetchOrders();
    } catch (err: any) {
      error('Update Failed', err.message);
    }
  };

  return (
    <div className="bg-white border border-stone-200 rounded-xl overflow-hidden shadow-xs">
      <div className="p-5 bg-stone-50 border-b border-stone-200 flex items-center justify-between">
        <div>
          <h2 className="text-base font-bold text-stone-900">
            Customer Orders & Fulfillment
          </h2>
          <p className="text-xs text-stone-500 mt-0.5">
            Real-time NoSQL order transactions and status tracking.
          </p>
        </div>
        <button
          onClick={fetchOrders}
          className="p-2 border border-stone-200 bg-white hover:bg-stone-50 text-stone-700 text-xs font-medium rounded-lg transition-colors flex items-center gap-1.5"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span>Refresh</span>
        </button>
      </div>

      {isLoading ? (
        <div className="p-12 text-center text-xs text-stone-500">Loading order database...</div>
      ) : orders.length === 0 ? (
        <div className="p-12 text-center text-xs text-stone-500">No customer orders recorded yet.</div>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-stone-100/70 border-b border-stone-200 text-stone-600 font-semibold uppercase tracking-wider">
              <tr>
                <th className="py-3 px-4">Order #</th>
                <th className="py-3 px-4">Customer</th>
                <th className="py-3 px-4">Items</th>
                <th className="py-3 px-4">Total</th>
                <th className="py-3 px-4">Payment</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Update Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-100">
              {orders.map((o) => (
                <tr key={o._id} className="hover:bg-stone-50/60 transition-colors">
                  <td className="py-3 px-4 font-mono font-semibold text-stone-900">
                    {o.orderNumber}
                  </td>
                  <td className="py-3 px-4">
                    <p className="font-semibold text-stone-900">{o.customer.name}</p>
                    <p className="text-[11px] text-stone-400">{o.customer.email}</p>
                  </td>
                  <td className="py-3 px-4 text-stone-600">
                    {o.items.length} {o.items.length === 1 ? 'item' : 'items'}
                    <span className="text-[11px] text-stone-400 block truncate max-w-xs">
                      {o.items.map(i => `${i.quantity}x ${i.product.title}`).join(', ')}
                    </span>
                  </td>
                  <td className="py-3 px-4 font-semibold text-stone-900 tabular-nums">
                    ${o.pricing.total.toFixed(2)}
                  </td>
                  <td className="py-3 px-4 uppercase text-[11px]">
                    <span className={`px-2 py-0.5 rounded font-medium ${
                      o.paymentStatus === 'paid' ? 'bg-emerald-50 text-emerald-800' : 'bg-amber-50 text-amber-800'
                    }`}>
                      {o.paymentMethod} · {o.paymentStatus}
                    </span>
                  </td>
                  <td className="py-3 px-4 capitalize font-medium text-stone-800">
                    {o.status}
                  </td>
                  <td className="py-3 px-4 text-right">
                    <select
                      value={o.status}
                      onChange={(e) => handleStatusChange(o._id, e.target.value)}
                      className="px-2 py-1 bg-stone-50 border border-stone-200 rounded text-xs text-stone-800 focus:outline-none"
                    >
                      <option value="confirmed">Confirmed</option>
                      <option value="processing">Processing</option>
                      <option value="shipped">Shipped</option>
                      <option value="delivered">Delivered</option>
                    </select>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};
