import React, { useState } from 'react';
import { Plus, Edit3, Trash2, Shield, Package, RefreshCw, X, Check, ArrowUpDown } from 'lucide-react';
import type { Product } from '../../types/index.ts';
import { api } from '../../api/client.ts';
import { useNotification } from '../../context/NotificationContext.tsx';

interface AdminCatalogManagerProps {
  products: Product[];
  onRefresh: () => void;
}

export const AdminCatalogManager: React.FC<AdminCatalogManagerProps> = ({
  products,
  onRefresh,
}) => {
  const { success, error } = useNotification();
  const [isEditing, setIsEditing] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

  // Form State
  const [title, setTitle] = useState('');
  const [subtitle, setSubtitle] = useState('');
  const [category, setCategory] = useState('Leather & Bags');
  const [price, setPrice] = useState(120);
  const [compareAtPrice, setCompareAtPrice] = useState<number | undefined>(undefined);
  const [stock, setStock] = useState(15);
  const [description, setDescription] = useState('');
  const [imageUrl, setImageUrl] = useState('/src/assets/images/lumina_leather_tote_1792496777297.jpg');
  const [tags, setTags] = useState('Handcrafted, Minimalist');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const openCreateModal = () => {
    setSelectedProduct(null);
    setTitle('');
    setSubtitle('');
    setCategory('Leather & Bags');
    setPrice(120);
    setCompareAtPrice(undefined);
    setStock(15);
    setDescription('');
    setImageUrl('/src/assets/images/lumina_leather_tote_1792496777297.jpg');
    setTags('Handcrafted, Minimalist');
    setIsEditing(true);
  };

  const openEditModal = (p: Product) => {
    setSelectedProduct(p);
    setTitle(p.title);
    setSubtitle(p.subtitle || '');
    setCategory(p.category);
    setPrice(p.price);
    setCompareAtPrice(p.compareAtPrice);
    setStock(p.stock);
    setDescription(p.description);
    setImageUrl(p.images?.[0] || '/src/assets/images/lumina_leather_tote_1792496777297.jpg');
    setTags(p.tags?.join(', ') || '');
    setIsEditing(true);
  };

  const handleSaveProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || price <= 0 || stock < 0) {
      error('Validation Error', 'Title, valid price, and stock are required.');
      return;
    }

    try {
      setIsSubmitting(true);
      const payload: Partial<Product> = {
        title,
        subtitle,
        category,
        price: Number(price),
        compareAtPrice: compareAtPrice ? Number(compareAtPrice) : undefined,
        stock: Number(stock),
        description,
        images: [imageUrl],
        tags: tags.split(',').map(t => t.trim()).filter(Boolean),
      };

      if (selectedProduct) {
        await api.updateProduct(selectedProduct._id, payload);
        success('Catalog Updated', `"${title}" was updated in MongoDB database.`);
      } else {
        await api.createProduct(payload);
        success('Product Created', `"${title}" was added to MongoDB catalog.`);
      }

      setIsEditing(false);
      onRefresh();
    } catch (err: any) {
      error('Operation Failed', err.message);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDelete = async (p: Product) => {
    if (!window.confirm(`Are you sure you want to permanently delete "${p.title}" from the catalog?`)) {
      return;
    }

    try {
      await api.deleteProduct(p._id);
      success('Product Deleted', `Removed "${p.title}" from NoSQL database.`);
      onRefresh();
    } catch (err: any) {
      error('Delete Failed', err.message);
    }
  };

  const handleQuickStockUpdate = async (p: Product, newStock: number) => {
    if (newStock < 0) return;
    try {
      await api.updateProduct(p._id, { stock: newStock });
      onRefresh();
    } catch (err: any) {
      error('Stock Update Failed', err.message);
    }
  };

  return (
    <div className="bg-white border border-stone-200 rounded-xl overflow-hidden shadow-xs">
      {/* Header Bar */}
      <div className="p-5 bg-stone-50 border-b border-stone-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Package className="w-5 h-5 text-stone-800" />
            <h2 className="text-base font-bold text-stone-900">
              Product Catalog Management
            </h2>
          </div>
          <p className="text-xs text-stone-500 mt-0.5">
            Admin console connected to MongoDB NoSQL document store with live inventory control.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onRefresh}
            className="p-2 border border-stone-200 bg-white hover:bg-stone-50 text-stone-700 text-xs font-medium rounded-lg transition-colors flex items-center gap-1.5"
            aria-label="Refresh catalog"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Sync</span>
          </button>
          <button
            onClick={openCreateModal}
            className="py-2 px-3.5 bg-stone-900 hover:bg-stone-800 text-stone-50 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 shadow-xs"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add New Product</span>
          </button>
        </div>
      </div>

      {/* Products Table */}
      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs">
          <thead className="bg-stone-100/70 border-b border-stone-200 text-stone-600 font-semibold uppercase tracking-wider">
            <tr>
              <th className="py-3 px-4">Item & Visual</th>
              <th className="py-3 px-4">Category</th>
              <th className="py-3 px-4">Price</th>
              <th className="py-3 px-4">Stock Inventory</th>
              <th className="py-3 px-4">Rating</th>
              <th className="py-3 px-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-stone-100">
            {products.map((p) => (
              <tr key={p._id} className="hover:bg-stone-50/60 transition-colors">
                <td className="py-3 px-4">
                  <div className="flex items-center gap-3">
                    <img
                      src={p.images?.[0] || '/src/assets/images/lumina_leather_tote_1792496777297.jpg'}
                      alt={p.title}
                      className="w-10 h-10 object-cover rounded-md border border-stone-200 bg-stone-100 shrink-0"
                    />
                    <div>
                      <p className="font-semibold text-stone-900 line-clamp-1">{p.title}</p>
                      <p className="text-[11px] text-stone-400 font-mono">ID: {p._id.slice(-6)}</p>
                    </div>
                  </div>
                </td>
                <td className="py-3 px-4 text-stone-700 font-medium">
                  {p.category}
                </td>
                <td className="py-3 px-4 text-stone-900 font-semibold tabular-nums">
                  ${p.price.toFixed(2)}
                  {p.compareAtPrice && (
                    <span className="text-[11px] text-stone-400 line-through block font-normal">
                      ${p.compareAtPrice.toFixed(2)}
                    </span>
                  )}
                </td>
                <td className="py-3 px-4">
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => handleQuickStockUpdate(p, p.stock - 1)}
                      className="w-5 h-5 bg-stone-100 hover:bg-stone-200 text-stone-600 rounded flex items-center justify-center font-bold"
                      aria-label="Decrease stock"
                    >
                      -
                    </button>
                    <span className={`w-8 text-center font-semibold tabular-nums ${
                      p.stock === 0 ? 'text-rose-600' : p.stock <= 5 ? 'text-amber-700' : 'text-stone-800'
                    }`}>
                      {p.stock}
                    </span>
                    <button
                      onClick={() => handleQuickStockUpdate(p, p.stock + 1)}
                      className="w-5 h-5 bg-stone-100 hover:bg-stone-200 text-stone-600 rounded flex items-center justify-center font-bold"
                      aria-label="Increase stock"
                    >
                      +
                    </button>
                  </div>
                </td>
                <td className="py-3 px-4 text-stone-700 tabular-nums">
                  ★ {p.rating.toFixed(1)} ({p.reviewCount})
                </td>
                <td className="py-3 px-4 text-right">
                  <div className="flex items-center justify-end gap-1">
                    <button
                      onClick={() => openEditModal(p)}
                      className="p-1.5 text-stone-500 hover:text-stone-900 hover:bg-stone-100 rounded transition-colors"
                      aria-label={`Edit ${p.title}`}
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => handleDelete(p)}
                      className="p-1.5 text-stone-400 hover:text-rose-600 hover:bg-rose-50 rounded transition-colors"
                      aria-label={`Delete ${p.title}`}
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Edit / Create Modal */}
      {isEditing && (
        <div className="fixed inset-0 z-50 overflow-y-auto" role="dialog" aria-modal="true">
          <div className="flex items-center justify-center min-h-screen px-4 pt-4 pb-20 text-center sm:block sm:p-0">
            <div className="fixed inset-0 bg-stone-900/60 backdrop-blur-xs" onClick={() => setIsEditing(false)} />

            <div className="inline-block align-bottom bg-white rounded-xl text-left overflow-hidden shadow-2xl transform transition-all sm:my-8 sm:align-middle sm:max-w-xl sm:w-full border border-stone-200">
              <div className="px-6 py-4 bg-stone-50 border-b border-stone-200 flex items-center justify-between">
                <h3 className="text-base font-bold text-stone-900">
                  {selectedProduct ? 'Edit Catalog Product' : 'Create New Product'}
                </h3>
                <button
                  onClick={() => setIsEditing(false)}
                  className="p-1.5 text-stone-400 hover:text-stone-700 rounded-lg"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleSaveProduct} className="p-6 space-y-4 text-xs">
                <div>
                  <label className="block font-medium text-stone-700 mb-1">Product Title *</label>
                  <input
                    type="text"
                    required
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="e.g. Minimalist Oak Bench"
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-lg focus:outline-none focus:border-stone-800 text-xs"
                  />
                </div>

                <div>
                  <label className="block font-medium text-stone-700 mb-1">Subtitle / Material Headline</label>
                  <input
                    type="text"
                    value={subtitle}
                    onChange={(e) => setSubtitle(e.target.value)}
                    placeholder="e.g. Solid European White Oak & Wax Oil"
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-lg focus:outline-none focus:border-stone-800 text-xs"
                  />
                </div>

                <div className="grid grid-cols-3 gap-3">
                  <div>
                    <label className="block font-medium text-stone-700 mb-1">Category *</label>
                    <select
                      value={category}
                      onChange={(e) => setCategory(e.target.value)}
                      className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-lg focus:outline-none focus:border-stone-800 text-xs"
                    >
                      <option value="Leather & Bags">Leather & Bags</option>
                      <option value="Audio & Acoustics">Audio & Acoustics</option>
                      <option value="Living & Ceramics">Living & Ceramics</option>
                      <option value="Desk & Architecture">Desk & Architecture</option>
                    </select>
                  </div>
                  <div>
                    <label className="block font-medium text-stone-700 mb-1">Price ($) *</label>
                    <input
                      type="number"
                      step="0.01"
                      required
                      value={price}
                      onChange={(e) => setPrice(Number(e.target.value))}
                      className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-lg focus:outline-none focus:border-stone-800 text-xs"
                    />
                  </div>
                  <div>
                    <label className="block font-medium text-stone-700 mb-1">Stock Units *</label>
                    <input
                      type="number"
                      required
                      value={stock}
                      onChange={(e) => setStock(Number(e.target.value))}
                      className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-lg focus:outline-none focus:border-stone-800 text-xs"
                    />
                  </div>
                </div>

                <div>
                  <label className="block font-medium text-stone-700 mb-1">Image Asset Path / URL</label>
                  <input
                    type="text"
                    value={imageUrl}
                    onChange={(e) => setImageUrl(e.target.value)}
                    placeholder="/src/assets/images/..."
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-lg focus:outline-none focus:border-stone-800 text-xs font-mono"
                  />
                </div>

                <div>
                  <label className="block font-medium text-stone-700 mb-1">Description</label>
                  <textarea
                    rows={3}
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="Product storytelling and details..."
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-lg focus:outline-none focus:border-stone-800 text-xs"
                  />
                </div>

                <div>
                  <label className="block font-medium text-stone-700 mb-1">Tags (comma-separated)</label>
                  <input
                    type="text"
                    value={tags}
                    onChange={(e) => setTags(e.target.value)}
                    placeholder="Handmade, Best Seller, New"
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-lg focus:outline-none focus:border-stone-800 text-xs"
                  />
                </div>

                <div className="pt-2 flex justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setIsEditing(false)}
                    className="px-4 py-2 border border-stone-200 text-stone-700 hover:bg-stone-50 rounded-lg text-xs font-semibold"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="px-5 py-2 bg-stone-900 hover:bg-stone-800 text-stone-50 rounded-lg text-xs font-semibold"
                  >
                    {isSubmitting ? 'Saving to Database...' : 'Save Product'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
