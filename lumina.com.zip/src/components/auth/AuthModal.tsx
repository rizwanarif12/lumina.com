import React, { useState } from 'react';
import { X, Lock, Mail, User as UserIcon, Shield, Sparkles } from 'lucide-react';
import { useAuth } from '../../context/AuthContext.tsx';

export const AuthModal: React.FC = () => {
  const { isAuthModalOpen, closeAuthModal, authModalTab, openAuthModal, login, register, quickLogin } = useAuth();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [role, setRole] = useState<'customer' | 'admin'>('customer');
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isAuthModalOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    if (authModalTab === 'login') {
      await login(email, password);
    } else {
      await register(name, email, password, role);
    }
    setIsSubmitting(false);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto" role="dialog" aria-modal="true" aria-labelledby="auth-modal-title">
      {/* Backdrop */}
      <div className="fixed inset-0 bg-stone-900/60 backdrop-blur-xs transition-opacity" onClick={closeAuthModal} aria-hidden="true" />

      <div className="relative z-10 flex items-center justify-center min-h-screen p-4 pointer-events-none">
        <div className="pointer-events-auto w-full max-w-md bg-white rounded-xl text-left overflow-hidden shadow-2xl border border-stone-200">
          {/* Header */}
          <div className="px-6 py-4 bg-stone-50 border-b border-stone-200 flex items-center justify-between">
            <h3 id="auth-modal-title" className="text-base font-semibold text-stone-900 tracking-tight">
              {authModalTab === 'login' ? 'Sign in to Lumina' : 'Create an Account'}
            </h3>
            <button
              onClick={closeAuthModal}
              className="p-1.5 text-stone-400 hover:text-stone-700 rounded-lg transition-colors"
              aria-label="Close modal"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Quick 1-Click Demo Logins */}
          <div className="p-4 bg-stone-100/60 border-b border-stone-200">
            <p className="text-[11px] font-semibold text-stone-500 uppercase tracking-wider mb-2">
              Instant Demo Access (No typing needed)
            </p>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => quickLogin('customer')}
                className="py-2 px-3 bg-white border border-stone-200 hover:border-stone-400 text-stone-800 text-xs font-semibold rounded-lg flex items-center justify-center gap-1.5 shadow-xs transition-colors"
              >
                <UserIcon className="w-3.5 h-3.5 text-stone-600" />
                <span>Demo Customer</span>
              </button>
              <button
                type="button"
                onClick={() => quickLogin('admin')}
                className="py-2 px-3 bg-stone-900 hover:bg-stone-800 text-stone-50 text-xs font-semibold rounded-lg flex items-center justify-center gap-1.5 shadow-xs transition-colors"
              >
                <Shield className="w-3.5 h-3.5 text-stone-200" />
                <span>Demo Admin</span>
              </button>
            </div>
          </div>

          {/* Tab buttons */}
          <div className="flex border-b border-stone-200">
            <button
              onClick={() => openAuthModal('login')}
              className={`flex-1 py-3 text-xs font-semibold text-center border-b-2 transition-colors ${
                authModalTab === 'login'
                  ? 'border-stone-900 text-stone-900'
                  : 'border-transparent text-stone-500 hover:text-stone-800'
              }`}
            >
              Sign In
            </button>
            <button
              onClick={() => openAuthModal('register')}
              className={`flex-1 py-3 text-xs font-semibold text-center border-b-2 transition-colors ${
                authModalTab === 'register'
                  ? 'border-stone-900 text-stone-900'
                  : 'border-transparent text-stone-500 hover:text-stone-800'
              }`}
            >
              Register
            </button>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="p-6 space-y-4">
            {authModalTab === 'register' && (
              <div>
                <label className="block text-xs font-medium text-stone-700 mb-1">Your Full Name *</label>
                <div className="relative">
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Marcus Vance"
                    className="w-full pl-9 pr-3 py-2 text-sm bg-stone-50 border border-stone-200 rounded-lg focus:outline-none focus:border-stone-800"
                  />
                  <UserIcon className="w-4 h-4 text-stone-400 absolute left-3 top-2.5" />
                </div>
              </div>
            )}

            <div>
              <label className="block text-xs font-medium text-stone-700 mb-1">Email Address *</label>
              <div className="relative">
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@example.com"
                  className="w-full pl-9 pr-3 py-2 text-sm bg-stone-50 border border-stone-200 rounded-lg focus:outline-none focus:border-stone-800"
                />
                <Mail className="w-4 h-4 text-stone-400 absolute left-3 top-2.5" />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-stone-700 mb-1">Password *</label>
              <div className="relative">
                <input
                  type="password"
                  required
                  minLength={6}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full pl-9 pr-3 py-2 text-sm bg-stone-50 border border-stone-200 rounded-lg focus:outline-none focus:border-stone-800"
                />
                <Lock className="w-4 h-4 text-stone-400 absolute left-3 top-2.5" />
              </div>
            </div>

            {authModalTab === 'register' && (
              <div>
                <label className="block text-xs font-medium text-stone-700 mb-1">Account Role</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setRole('customer')}
                    className={`py-2 px-3 text-xs rounded-lg border font-medium transition-colors ${
                      role === 'customer'
                        ? 'border-stone-900 bg-stone-900 text-stone-50'
                        : 'border-stone-200 text-stone-700 hover:bg-stone-50'
                    }`}
                  >
                    Customer
                  </button>
                  <button
                    type="button"
                    onClick={() => setRole('admin')}
                    className={`py-2 px-3 text-xs rounded-lg border font-medium transition-colors ${
                      role === 'admin'
                        ? 'border-stone-900 bg-stone-900 text-stone-50'
                        : 'border-stone-200 text-stone-700 hover:bg-stone-50'
                    }`}
                  >
                    Store Admin
                  </button>
                </div>
              </div>
            )}

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-3 px-4 bg-stone-900 hover:bg-stone-800 text-stone-50 text-xs font-semibold uppercase tracking-wider rounded-lg transition-colors disabled:opacity-50 mt-2"
            >
              {isSubmitting
                ? 'Processing...'
                : authModalTab === 'login'
                ? 'Sign In to Account'
                : 'Create Lumina Account'}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
