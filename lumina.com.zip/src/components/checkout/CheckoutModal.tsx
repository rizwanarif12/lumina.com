import React, { useState } from 'react';
import { X, Lock, CheckCircle, CreditCard, Truck, ChevronRight, AlertCircle, ShoppingBag } from 'lucide-react';
import { useCart } from '../../context/CartContext.tsx';
import { useAuth } from '../../context/AuthContext.tsx';
import { api } from '../../api/client.ts';
import type { Order, Address } from '../../types/index.ts';
import { useNotification } from '../../context/NotificationContext.tsx';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOrderSuccess: (order: Order) => void;
}

export const CheckoutModal: React.FC<CheckoutModalProps> = ({
  isOpen,
  onClose,
  onOrderSuccess,
}) => {
  const { items, totals, shippingMethod, setShippingMethod, promoCode, clearCart } = useCart();
  const { user, isAuthenticated } = useAuth();
  const { error, success } = useNotification();

  const [step, setStep] = useState<1 | 2 | 3>(1);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Shipping Form State
  const [shippingAddress, setShippingAddress] = useState<Address>({
    fullName: user?.name || '',
    street: user?.address?.street || '',
    city: user?.address?.city || '',
    state: user?.address?.state || 'CA',
    postalCode: user?.address?.postalCode || '',
    country: 'United States',
    phone: user?.address?.phone || '',
  });
  const [contactEmail, setContactEmail] = useState(user?.email || '');

  // Payment Form State
  const [paymentMethod, setPaymentMethod] = useState<'card' | 'cod'>('card');
  const [cardNumber, setCardNumber] = useState('4242 •••• •••• 4242');
  const [cardExpiry, setCardExpiry] = useState('12/28');
  const [cardCvc, setCardCvc] = useState('888');

  if (!isOpen) return null;

  const handleAddressSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!shippingAddress.fullName || !contactEmail || !shippingAddress.street || !shippingAddress.city || !shippingAddress.postalCode) {
      setErrorMessage('Please fill in all required shipping address fields.');
      return;
    }
    setErrorMessage(null);
    setStep(2);
  };

  const handlePlaceOrder = async () => {
    try {
      setIsSubmitting(true);
      setErrorMessage(null);

      const orderPayload = {
        items: items.map(item => ({
          product: { _id: item.product._id, price: item.product.price, title: item.product.title },
          quantity: item.quantity,
          selectedVariant: item.selectedVariant,
        })),
        shippingAddress: {
          ...shippingAddress,
          email: contactEmail,
        },
        shippingMethod,
        paymentMethod,
        promoCode,
      };

      const response = await api.createOrder(orderPayload);

      if (response.success && response.data) {
        success('Order Confirmed!', `Order #${response.data.orderNumber} placed.`);
        clearCart();
        onOrderSuccess(response.data);
        onClose();
      } else {
        throw new Error(response.error || 'Failed to finalize order');
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'Payment processing failed. Please check your inventory or payment details.');
      error('Checkout Error', err.message);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto" role="dialog" aria-modal="true" aria-labelledby="checkout-title">
      {/* Backdrop */}
      <div className="fixed inset-0 bg-stone-900/60 backdrop-blur-xs transition-opacity" onClick={onClose} aria-hidden="true" />

      <div className="relative z-10 flex items-center justify-center min-h-screen p-4 pointer-events-none">
        <div className="pointer-events-auto w-full max-w-2xl bg-white rounded-xl text-left overflow-hidden shadow-2xl border border-stone-200">
          {/* Header */}
          <div className="px-6 py-4 bg-stone-50 border-b border-stone-200 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Lock className="w-4 h-4 text-stone-700" />
              <h3 id="checkout-title" className="text-base font-semibold text-stone-900">
                Secure Checkout
              </h3>
            </div>
            <button
              onClick={onClose}
              className="p-1.5 text-stone-400 hover:text-stone-700 rounded-lg transition-colors"
              aria-label="Close checkout"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Stepper Tabs */}
          <div className="px-6 py-3 bg-stone-100/70 border-b border-stone-200 flex items-center justify-between text-xs font-medium">
            <button
              onClick={() => setStep(1)}
              className={`flex items-center gap-1.5 transition-colors ${
                step === 1 ? 'text-stone-900 font-semibold' : 'text-stone-500'
              }`}
            >
              <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] ${
                step >= 1 ? 'bg-stone-900 text-white' : 'bg-stone-300 text-stone-700'
              }`}>1</span>
              <span>Shipping & Contact</span>
            </button>
            <ChevronRight className="w-3.5 h-3.5 text-stone-400" />

            <button
              onClick={() => step > 1 && setStep(2)}
              className={`flex items-center gap-1.5 transition-colors ${
                step === 2 ? 'text-stone-900 font-semibold' : 'text-stone-500'
              }`}
            >
              <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] ${
                step >= 2 ? 'bg-stone-900 text-white' : 'bg-stone-300 text-stone-700'
              }`}>2</span>
              <span>Delivery & Payment</span>
            </button>
            <ChevronRight className="w-3.5 h-3.5 text-stone-400" />

            <button
              onClick={() => step === 3 && setStep(3)}
              className={`flex items-center gap-1.5 transition-colors ${
                step === 3 ? 'text-stone-900 font-semibold' : 'text-stone-500'
              }`}
            >
              <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] ${
                step === 3 ? 'bg-stone-900 text-white' : 'bg-stone-300 text-stone-700'
              }`}>3</span>
              <span>Review & Place Order</span>
            </button>
          </div>

          {/* Error Notice */}
          {errorMessage && (
            <div className="mx-6 mt-4 p-3 bg-rose-50 border border-rose-200 rounded-lg flex items-center gap-2 text-xs text-rose-800">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
              <span>{errorMessage}</span>
            </div>
          )}

          <div className="p-6">
            {/* Step 1: Shipping Address */}
            {step === 1 && (
              <form onSubmit={handleAddressSubmit} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-stone-700 mb-1">Full Recipient Name *</label>
                    <input
                      type="text"
                      required
                      value={shippingAddress.fullName}
                      onChange={(e) => setShippingAddress({ ...shippingAddress, fullName: e.target.value })}
                      placeholder="Jane Doe"
                      className="w-full px-3 py-2 text-sm bg-stone-50 border border-stone-200 rounded-lg focus:outline-none focus:border-stone-800"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-stone-700 mb-1">Contact Email Address *</label>
                    <input
                      type="email"
                      required
                      value={contactEmail}
                      onChange={(e) => setContactEmail(e.target.value)}
                      placeholder="jane@example.com"
                      className="w-full px-3 py-2 text-sm bg-stone-50 border border-stone-200 rounded-lg focus:outline-none focus:border-stone-800"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium text-stone-700 mb-1">Street Address *</label>
                  <input
                    type="text"
                    required
                    value={shippingAddress.street}
                    onChange={(e) => setShippingAddress({ ...shippingAddress, street: e.target.value })}
                    placeholder="742 Evergreen Terrace, Apt 4B"
                    className="w-full px-3 py-2 text-sm bg-stone-50 border border-stone-200 rounded-lg focus:outline-none focus:border-stone-800"
                  />
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-stone-700 mb-1">City *</label>
                    <input
                      type="text"
                      required
                      value={shippingAddress.city}
                      onChange={(e) => setShippingAddress({ ...shippingAddress, city: e.target.value })}
                      placeholder="Portland"
                      className="w-full px-3 py-2 text-sm bg-stone-50 border border-stone-200 rounded-lg focus:outline-none focus:border-stone-800"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-stone-700 mb-1">State / Province</label>
                    <input
                      type="text"
                      value={shippingAddress.state}
                      onChange={(e) => setShippingAddress({ ...shippingAddress, state: e.target.value })}
                      placeholder="OR"
                      className="w-full px-3 py-2 text-sm bg-stone-50 border border-stone-200 rounded-lg focus:outline-none focus:border-stone-800"
                    />
                  </div>
                  <div className="col-span-2 sm:col-span-1">
                    <label className="block text-xs font-medium text-stone-700 mb-1">Postal Code *</label>
                    <input
                      type="text"
                      required
                      value={shippingAddress.postalCode}
                      onChange={(e) => setShippingAddress({ ...shippingAddress, postalCode: e.target.value })}
                      placeholder="97201"
                      className="w-full px-3 py-2 text-sm bg-stone-50 border border-stone-200 rounded-lg focus:outline-none focus:border-stone-800"
                    />
                  </div>
                </div>

                <div className="pt-2 flex items-center justify-between">
                  <span className="text-xs text-stone-500">
                    {isAuthenticated ? `Signed in as ${user?.name}` : 'Checking out as Guest'}
                  </span>
                  <button
                    type="submit"
                    className="px-6 py-2.5 bg-stone-900 text-stone-50 text-xs font-semibold rounded-lg hover:bg-stone-800 transition-colors flex items-center gap-1.5"
                  >
                    <span>Continue to Delivery</span>
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </form>
            )}

            {/* Step 2: Delivery & Payment Method */}
            {step === 2 && (
              <div className="space-y-6">
                <div>
                  <h4 className="text-xs font-semibold text-stone-900 uppercase tracking-wider mb-2.5">
                    Shipping Method
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <label
                      className={`p-3.5 border rounded-lg flex items-start gap-3 cursor-pointer transition-all ${
                        shippingMethod === 'standard'
                          ? 'border-stone-900 bg-stone-50/80 ring-1 ring-stone-900'
                          : 'border-stone-200 hover:border-stone-300'
                      }`}
                    >
                      <input
                        type="radio"
                        name="shippingMethod"
                        value="standard"
                        checked={shippingMethod === 'standard'}
                        onChange={() => setShippingMethod('standard')}
                        className="mt-0.5 text-stone-900 focus:ring-stone-900"
                      />
                      <div className="flex-1 text-xs">
                        <div className="flex justify-between font-semibold text-stone-900">
                          <span>Standard Courier</span>
                          <span className="tabular-nums">
                            {totals.freeShippingQualified || promoCode === 'FREESHIP' ? 'Free' : '$12.00'}
                          </span>
                        </div>
                        <p className="text-stone-500 mt-0.5">3–5 business days, carbon neutral</p>
                      </div>
                    </label>

                    <label
                      className={`p-3.5 border rounded-lg flex items-start gap-3 cursor-pointer transition-all ${
                        shippingMethod === 'express'
                          ? 'border-stone-900 bg-stone-50/80 ring-1 ring-stone-900'
                          : 'border-stone-200 hover:border-stone-300'
                      }`}
                    >
                      <input
                        type="radio"
                        name="shippingMethod"
                        value="express"
                        checked={shippingMethod === 'express'}
                        onChange={() => setShippingMethod('express')}
                        className="mt-0.5 text-stone-900 focus:ring-stone-900"
                      />
                      <div className="flex-1 text-xs">
                        <div className="flex justify-between font-semibold text-stone-900">
                          <span>Express Air Priority</span>
                          <span className="tabular-nums">$28.00</span>
                        </div>
                        <p className="text-stone-500 mt-0.5">1–2 business days guaranteed</p>
                      </div>
                    </label>
                  </div>
                </div>

                <div>
                  <h4 className="text-xs font-semibold text-stone-900 uppercase tracking-wider mb-2.5">
                    Payment Architecture
                  </h4>
                  <div className="grid grid-cols-2 gap-3 mb-3">
                    <button
                      type="button"
                      onClick={() => setPaymentMethod('card')}
                      className={`p-3 border rounded-lg flex items-center justify-center gap-2 text-xs font-medium transition-all ${
                        paymentMethod === 'card'
                          ? 'border-stone-900 bg-stone-900 text-stone-50'
                          : 'border-stone-200 text-stone-700 hover:bg-stone-50'
                      }`}
                    >
                      <CreditCard className="w-4 h-4" />
                      <span>Credit / Debit Card</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setPaymentMethod('cod')}
                      className={`p-3 border rounded-lg flex items-center justify-center gap-2 text-xs font-medium transition-all ${
                        paymentMethod === 'cod'
                          ? 'border-stone-900 bg-stone-900 text-stone-50'
                          : 'border-stone-200 text-stone-700 hover:bg-stone-50'
                      }`}
                    >
                      <Truck className="w-4 h-4" />
                      <span>Cash on Delivery</span>
                    </button>
                  </div>

                  {paymentMethod === 'card' && (
                    <div className="p-4 bg-stone-50 border border-stone-200 rounded-lg space-y-3">
                      <div>
                        <label className="block text-[11px] font-medium text-stone-600 mb-1">Card Number</label>
                        <input
                          type="text"
                          value={cardNumber}
                          onChange={(e) => setCardNumber(e.target.value)}
                          placeholder="4242 •••• •••• 4242"
                          className="w-full px-3 py-1.5 text-xs bg-white border border-stone-200 rounded font-mono focus:outline-none focus:border-stone-800"
                        />
                      </div>
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <label className="block text-[11px] font-medium text-stone-600 mb-1">Expires (MM/YY)</label>
                          <input
                            type="text"
                            value={cardExpiry}
                            onChange={(e) => setCardExpiry(e.target.value)}
                            placeholder="12/28"
                            className="w-full px-3 py-1.5 text-xs bg-white border border-stone-200 rounded font-mono focus:outline-none focus:border-stone-800"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] font-medium text-stone-600 mb-1">CVC Code</label>
                          <input
                            type="password"
                            maxLength={4}
                            value={cardCvc}
                            onChange={(e) => setCardCvc(e.target.value)}
                            placeholder="•••"
                            className="w-full px-3 py-1.5 text-xs bg-white border border-stone-200 rounded font-mono focus:outline-none focus:border-stone-800"
                          />
                        </div>
                      </div>
                    </div>
                  )}

                  {paymentMethod === 'cod' && (
                    <div className="p-3.5 bg-amber-50 border border-amber-200 rounded-lg text-xs text-amber-900">
                      You will pay directly in cash or terminal upon package inspection and handover at your address.
                    </div>
                  )}
                </div>

                <div className="pt-2 flex items-center justify-between">
                  <button
                    type="button"
                    onClick={() => setStep(1)}
                    className="text-xs text-stone-500 hover:text-stone-900 font-medium"
                  >
                    ← Back to Shipping
                  </button>
                  <button
                    type="button"
                    onClick={() => setStep(3)}
                    className="px-6 py-2.5 bg-stone-900 text-stone-50 text-xs font-semibold rounded-lg hover:bg-stone-800 transition-colors flex items-center gap-1.5"
                  >
                    <span>Review Order</span>
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}

            {/* Step 3: Review & Place Order */}
            {step === 3 && (
              <div className="space-y-5">
                {/* Order Summary Snapshot */}
                <div className="border border-stone-200 rounded-lg divide-y divide-stone-100 overflow-hidden">
                  <div className="p-3.5 bg-stone-50 flex justify-between items-center text-xs">
                    <span className="font-semibold text-stone-800">
                      Shipping to {shippingAddress.fullName}
                    </span>
                    <button
                      type="button"
                      onClick={() => setStep(1)}
                      className="text-stone-600 hover:text-stone-900 underline"
                    >
                      Edit
                    </button>
                  </div>
                  <div className="p-3.5 text-xs text-stone-600">
                    <p>{shippingAddress.street}</p>
                    <p>{shippingAddress.city}, {shippingAddress.state} {shippingAddress.postalCode}</p>
                    <p className="text-stone-400 mt-1">{contactEmail} · {shippingMethod.toUpperCase()} Delivery</p>
                  </div>
                </div>

                {/* Items brief preview */}
                <div className="max-h-40 overflow-y-auto divide-y divide-stone-100 border border-stone-200 rounded-lg p-3 space-y-2">
                  {items.map(i => (
                    <div key={i.product._id} className="flex justify-between items-center text-xs pt-1 first:pt-0">
                      <span className="truncate pr-2 text-stone-800">
                        {i.quantity}x {i.product.title}
                      </span>
                      <span className="tabular-nums font-medium text-stone-900">
                        ${(i.product.price * i.quantity).toFixed(2)}
                      </span>
                    </div>
                  ))}
                </div>

                {/* Price Breakdown */}
                <div className="p-4 bg-stone-50 rounded-lg space-y-2 text-xs text-stone-600">
                  <div className="flex justify-between">
                    <span>Subtotal</span>
                    <span className="tabular-nums font-medium text-stone-900">${totals.subtotal.toFixed(2)}</span>
                  </div>
                  {totals.discount > 0 && (
                    <div className="flex justify-between text-emerald-700 font-medium">
                      <span>Discount ({promoCode})</span>
                      <span className="tabular-nums">-${totals.discount.toFixed(2)}</span>
                    </div>
                  )}
                  <div className="flex justify-between">
                    <span>Shipping</span>
                    <span className="tabular-nums font-medium text-stone-900">
                      {totals.shipping === 0 ? 'Free' : `$${totals.shipping.toFixed(2)}`}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span>Sales Tax (8.5%)</span>
                    <span className="tabular-nums font-medium text-stone-900">${totals.tax.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-sm font-bold text-stone-900 pt-2 border-t border-stone-200">
                    <span>Total Charged</span>
                    <span className="tabular-nums text-base">${totals.total.toFixed(2)}</span>
                  </div>
                </div>

                <div className="pt-2 flex items-center justify-between">
                  <button
                    type="button"
                    onClick={() => setStep(2)}
                    className="text-xs text-stone-500 hover:text-stone-900 font-medium"
                  >
                    ← Back to Delivery
                  </button>
                  <button
                    type="button"
                    disabled={isSubmitting}
                    onClick={handlePlaceOrder}
                    className="px-8 py-3 bg-stone-900 text-stone-50 text-xs font-semibold uppercase tracking-wider rounded-lg hover:bg-stone-800 transition-colors disabled:opacity-50 flex items-center gap-2 shadow-sm"
                  >
                    {isSubmitting ? (
                      <span>Verifying & Placing Order...</span>
                    ) : (
                      <>
                        <span>Place Order · ${totals.total.toFixed(2)}</span>
                        <CheckCircle className="w-4 h-4 text-emerald-400" />
                      </>
                    )}
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
