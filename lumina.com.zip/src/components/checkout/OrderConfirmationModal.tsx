import React from 'react';
import { CheckCircle2, PackageCheck, Printer, ArrowRight, Truck } from 'lucide-react';
import type { Order } from '../../types/index.ts';

interface OrderConfirmationModalProps {
  order: Order | null;
  isOpen: boolean;
  onClose: () => void;
}

export const OrderConfirmationModal: React.FC<OrderConfirmationModalProps> = ({
  order,
  isOpen,
  onClose,
}) => {
  if (!isOpen || !order) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto" role="dialog" aria-modal="true" aria-labelledby="order-success-title">
      {/* Backdrop */}
      <div className="fixed inset-0 bg-stone-900/60 backdrop-blur-xs transition-opacity" onClick={onClose} aria-hidden="true" />

      <div className="relative z-10 flex items-center justify-center min-h-screen p-4 pointer-events-none">
        <div className="pointer-events-auto w-full max-w-lg bg-white rounded-xl text-left overflow-hidden shadow-2xl border border-stone-200">
          <div className="p-6 text-center border-b border-stone-100 bg-stone-50">
            <div className="w-14 h-14 bg-emerald-100 text-emerald-800 rounded-full flex items-center justify-center mx-auto mb-3">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <h3 id="order-success-title" className="text-xl font-bold text-stone-900 tracking-tight">
              Order Confirmed
            </h3>
            <p className="text-xs text-stone-500 mt-1">
              Thank you for shopping with Lumina. We are preparing your shipment.
            </p>
            <div className="mt-3 inline-block px-3 py-1 bg-white border border-stone-200 rounded-md text-xs font-mono font-semibold text-stone-800">
              Order #{order.orderNumber}
            </div>
          </div>

          <div className="p-6 space-y-4">
            {/* Delivery status indicator */}
            <div className="p-3 bg-stone-50 border border-stone-200 rounded-lg flex items-center gap-3 text-xs text-stone-700">
              <Truck className="w-4 h-4 text-stone-600 shrink-0" />
              <div>
                <p className="font-semibold text-stone-900 capitalize">Status: {order.status}</p>
                <p className="text-stone-500">
                  Estimated delivery in {order.shippingMethod === 'express' ? '1–2' : '3–5'} business days.
                </p>
              </div>
            </div>

            {/* Recipient info */}
            <div className="text-xs text-stone-600 space-y-1 bg-stone-50/50 p-3.5 rounded-lg border border-stone-100">
              <p className="font-semibold text-stone-900 mb-1">Shipping Details</p>
              <p>{order.shippingAddress.fullName}</p>
              <p>{order.shippingAddress.street}</p>
              <p>{order.shippingAddress.city}, {order.shippingAddress.state} {order.shippingAddress.postalCode}</p>
              <p className="text-stone-400 mt-1">{order.customer.email}</p>
            </div>

            {/* Items summary */}
            <div className="border border-stone-200 rounded-lg overflow-hidden divide-y divide-stone-100 text-xs">
              <div className="p-2.5 bg-stone-50 font-semibold text-stone-700">Purchased Items</div>
              <div className="max-h-36 overflow-y-auto divide-y divide-stone-100 p-2">
                {order.items.map((i, idx) => (
                  <div key={idx} className="py-1.5 flex justify-between items-center text-stone-800">
                    <span className="truncate pr-2">
                      {i.quantity}x {i.product.title}
                    </span>
                    <span className="tabular-nums font-semibold shrink-0">
                      ${(i.product.price * i.quantity).toFixed(2)}
                    </span>
                  </div>
                ))}
              </div>
              <div className="p-3 bg-stone-50 flex justify-between font-bold text-stone-900">
                <span>Total Paid</span>
                <span className="tabular-nums">${order.pricing.total.toFixed(2)}</span>
              </div>
            </div>

            {/* Actions */}
            <div className="pt-2 flex gap-3">
              <button
                onClick={() => window.print()}
                className="flex-1 py-2.5 px-3 border border-stone-200 text-stone-700 hover:bg-stone-50 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
              >
                <Printer className="w-4 h-4" />
                <span>Print Receipt</span>
              </button>
              <button
                onClick={onClose}
                className="flex-1 py-2.5 px-3 bg-stone-900 text-stone-50 hover:bg-stone-800 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
              >
                <span>Continue Shopping</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
