import React from 'react';
import { ShoppingBag, User as UserIcon, Shield, LogOut, Package } from 'lucide-react';
import { useCart } from '../../context/CartContext.tsx';
import { useAuth } from '../../context/AuthContext.tsx';

interface NavbarProps {
  activeView: 'store' | 'admin';
  setActiveView: (view: 'store' | 'admin') => void;
  onOpenSearch?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeView,
  setActiveView,
}) => {
  const { openDrawer, totalItemCount } = useCart();
  const { user, isAuthenticated, isAdmin, logout, openAuthModal } = useAuth();

  return (
    <header className="sticky top-0 z-40 bg-stone-50/90 backdrop-blur-md border-b border-stone-200 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-8">
        {/* Zone 1: Brand Wordmark (Single text element) */}
        <button
          onClick={() => setActiveView('store')}
          className="text-lg font-bold tracking-tight text-stone-900 whitespace-nowrap shrink-0 hover:opacity-80 transition-opacity"
        >
          Lumina
        </button>

        {/* Zone 2: Clean single-line text navigation links */}
        <nav className="hidden md:flex items-center gap-6 text-xs font-semibold uppercase tracking-wider text-stone-600">
          <button
            onClick={() => setActiveView('store')}
            className={`hover:text-stone-900 transition-colors whitespace-nowrap shrink-0 ${
              activeView === 'store' ? 'text-stone-900 border-b-2 border-stone-900 pb-1' : ''
            }`}
          >
            Catalog
          </button>
          <a
            href="#featured-section"
            onClick={() => setActiveView('store')}
            className="hover:text-stone-900 transition-colors whitespace-nowrap shrink-0"
          >
            Featured
          </a>
          <a
            href="#craftsmanship"
            onClick={() => setActiveView('store')}
            className="hover:text-stone-900 transition-colors whitespace-nowrap shrink-0"
          >
            Craftsmanship
          </a>

          {isAdmin && (
            <button
              onClick={() => setActiveView(activeView === 'admin' ? 'store' : 'admin')}
              className={`hover:text-stone-900 transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 ${
                activeView === 'admin' ? 'text-stone-900 font-bold' : 'text-stone-500'
              }`}
            >
              <Shield className="w-3.5 h-3.5" />
              <span>Admin Console</span>
            </button>
          )}
        </nav>

        {/* Zone 3: Account & Shopping Bag Actions */}
        <div className="flex items-center gap-3 shrink-0">
          {isAuthenticated ? (
            <div className="flex items-center gap-2">
              <span className="hidden sm:inline-block text-xs font-medium text-stone-700 truncate max-w-[120px]">
                {user?.name}
              </span>
              <button
                onClick={logout}
                className="p-2 text-stone-500 hover:text-stone-900 hover:bg-stone-100 rounded-lg transition-colors"
                title="Sign Out"
                aria-label="Sign out"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <button
              onClick={() => openAuthModal('login')}
              className="px-3.5 py-1.5 text-xs font-semibold text-stone-700 hover:text-stone-900 hover:bg-stone-100 rounded-lg transition-colors whitespace-nowrap flex items-center gap-1.5"
            >
              <UserIcon className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Sign In</span>
            </button>
          )}

          {/* Cart Drawer Trigger */}
          <button
            onClick={openDrawer}
            className="relative p-2.5 bg-stone-900 hover:bg-stone-800 text-stone-50 rounded-lg transition-colors flex items-center gap-2 shadow-xs"
            aria-label={`Open shopping bag with ${totalItemCount} items`}
          >
            <ShoppingBag className="w-4 h-4" />
            <span className="hidden sm:inline text-xs font-semibold">Bag</span>
            {totalItemCount > 0 && (
              <span className="w-4 h-4 rounded-full bg-stone-50 text-stone-900 text-[10px] font-bold flex items-center justify-center tabular-nums">
                {totalItemCount}
              </span>
            )}
          </button>
        </div>
      </div>
    </header>
  );
};
