import React from 'react';
import { ShoppingBag, Grid, User, Shield } from 'lucide-react';
import { useCart } from '../../context/CartContext.tsx';
import { useAuth } from '../../context/AuthContext.tsx';

interface MobileNavProps {
  activeView: 'store' | 'admin';
  setActiveView: (view: 'store' | 'admin') => void;
}

export const MobileNav: React.FC<MobileNavProps> = ({
  activeView,
  setActiveView,
}) => {
  const { openDrawer, totalItemCount } = useCart();
  const { isAuthenticated, isAdmin, openAuthModal, user } = useAuth();

  return (
    <nav className="fixed bottom-0 inset-x-0 z-40 bg-white/95 backdrop-blur-md border-t border-stone-200 md:hidden h-14 px-4 flex items-center justify-around">
      <button
        onClick={() => setActiveView('store')}
        className={`flex flex-col items-center justify-center gap-1 text-[10px] font-medium transition-colors ${
          activeView === 'store' ? 'text-stone-900 font-bold' : 'text-stone-500'
        }`}
      >
        <Grid className="w-4 h-4" />
        <span>Catalog</span>
      </button>

      <button
        onClick={openDrawer}
        className="relative flex flex-col items-center justify-center gap-1 text-[10px] font-medium text-stone-500 hover:text-stone-900 transition-colors"
      >
        <div className="relative">
          <ShoppingBag className="w-4 h-4" />
          {totalItemCount > 0 && (
            <span className="absolute -top-1.5 -right-2 w-3.5 h-3.5 bg-stone-900 text-stone-50 rounded-full text-[9px] font-bold flex items-center justify-center tabular-nums">
              {totalItemCount}
            </span>
          )}
        </div>
        <span>Bag</span>
      </button>

      {isAdmin && (
        <button
          onClick={() => setActiveView(activeView === 'admin' ? 'store' : 'admin')}
          className={`flex flex-col items-center justify-center gap-1 text-[10px] font-medium transition-colors ${
            activeView === 'admin' ? 'text-stone-900 font-bold' : 'text-stone-500'
          }`}
        >
          <Shield className="w-4 h-4" />
          <span>Admin</span>
        </button>
      )}

      <button
        onClick={() => {
          if (!isAuthenticated) openAuthModal('login');
        }}
        className="flex flex-col items-center justify-center gap-1 text-[10px] font-medium text-stone-500 hover:text-stone-900 transition-colors"
      >
        <User className="w-4 h-4" />
        <span className="truncate max-w-[50px]">{isAuthenticated ? user?.name?.split(' ')[0] : 'Sign In'}</span>
      </button>
    </nav>
  );
};
