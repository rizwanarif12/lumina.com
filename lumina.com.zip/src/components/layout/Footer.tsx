import React from 'react';
import { ShieldCheck, Truck, RotateCcw } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-stone-900 text-stone-300 pt-16 pb-20 sm:pb-12 border-t border-stone-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Value pillars */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-8 pb-12 border-b border-stone-800 text-xs">
          <div className="flex items-start gap-3">
            <Truck className="w-5 h-5 text-stone-400 shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold text-stone-100">Complimentary Courier</p>
              <p className="text-stone-400 mt-0.5 leading-relaxed">
                Free standard carbon-neutral shipping on all orders over $150.
              </p>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <RotateCcw className="w-5 h-5 text-stone-400 shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold text-stone-100">Guaranteed Longevity</p>
              <p className="text-stone-400 mt-0.5 leading-relaxed">
                30-day effortless returns and a two-year structural warranty on all goods.
              </p>
            </div>
          </div>
          <div className="flex items-start gap-3">
            <ShieldCheck className="w-5 h-5 text-stone-400 shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold text-stone-100">Secure Architecture</p>
              <p className="text-stone-400 mt-0.5 leading-relaxed">
                End-to-end encrypted checkout with real-time NoSQL state reconciliation.
              </p>
            </div>
          </div>
        </div>

        {/* Footer Navigation */}
        <div className="py-12 grid grid-cols-2 md:grid-cols-4 gap-8 text-xs">
          <div>
            <h4 className="font-bold text-stone-100 tracking-wider uppercase mb-3">Lumina</h4>
            <p className="text-stone-400 leading-relaxed pr-4">
              Architectural home goods, artisanal leather accessories, and acoustic hardware engineered for considered spaces.
            </p>
          </div>
          <div>
            <h4 className="font-semibold text-stone-100 uppercase tracking-wider mb-3">Collections</h4>
            <ul className="space-y-2 text-stone-400">
              <li><a href="#catalog" className="hover:text-stone-100 transition-colors">Leather & Bags</a></li>
              <li><a href="#catalog" className="hover:text-stone-100 transition-colors">Audio & Acoustics</a></li>
              <li><a href="#catalog" className="hover:text-stone-100 transition-colors">Living & Ceramics</a></li>
              <li><a href="#catalog" className="hover:text-stone-100 transition-colors">Desk & Architecture</a></li>
            </ul>
          </div>
          <div>
            <h4 className="font-semibold text-stone-100 uppercase tracking-wider mb-3">Client Care</h4>
            <ul className="space-y-2 text-stone-400">
              <li><a href="#care" className="hover:text-stone-100 transition-colors">Order Tracking</a></li>
              <li><a href="#care" className="hover:text-stone-100 transition-colors">Shipping Guidelines</a></li>
              <li><a href="#care" className="hover:text-stone-100 transition-colors">Warranty & Repairs</a></li>
              <li><a href="#care" className="hover:text-stone-100 transition-colors">Material Sourcing</a></li>
            </ul>
          </div>
          <div>
            <h4 className="font-semibold text-stone-100 uppercase tracking-wider mb-3">Newsletter</h4>
            <p className="text-stone-400 mb-3 leading-relaxed">
              Curated architectural insights and limited studio editions.
            </p>
            <div className="flex gap-2">
              <input
                type="email"
                placeholder="Email address"
                className="bg-stone-800 border border-stone-700 px-3 py-2 rounded-lg text-xs text-stone-100 focus:outline-none focus:border-stone-400 w-full"
              />
              <button
                type="button"
                className="bg-stone-100 text-stone-900 font-semibold px-3 py-2 rounded-lg text-xs hover:bg-stone-200 transition-colors shrink-0"
              >
                Join
              </button>
            </div>
          </div>
        </div>

        {/* Copyright */}
        <div className="pt-8 border-t border-stone-800 text-xs text-stone-500 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p>© {new Date().getFullYear()} Lumina Goods Co. All rights reserved.</p>
          <div className="flex items-center gap-4">
            <span className="hover:text-stone-400 cursor-pointer">Privacy Policy</span>
            <span className="hover:text-stone-400 cursor-pointer">Terms of Service</span>
            <span className="hover:text-stone-400 cursor-pointer">Security Audits</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
