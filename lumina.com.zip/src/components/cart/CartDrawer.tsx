import React, { useState } from 'react';
import { X, Plus, Minus, Trash2, ArrowRight, ShieldCheck, Tag, ShoppingBag } from 'lucide-react';
import { useCart } from '../../context/CartContext.tsx';
import { FREE_SHIPPING_THRESHOLD } from '../../utils/calculations.ts';

interface CartDrawerProps {
  onCheckout: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({ onCheckout }) => {
  const {
    items,
    isDrawerOpen,
    closeDrawer,
    updateQuantity,
    removeFromCart,
    totals,
    totalItemCount,
    promoCode,
    applyPromoCode,
    removePromoCode,
  } = useCart();

  const [inputCode, setInputCode] = useState('');
  const [isApplyingCode, setIsApplyingCode] = useState(false);

  if (!isDrawerOpen) return null;

  const handleApplyCode = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputCode.trim()) return;
    setIsApplyingCode(true);
    applyPromoCode(inputCode);
    setIsApplyingCode(false);
    setInputCode('');
  };

  const progressPercent = Math.min(100, Math.round((totals.subtotal / FREE_SHIPPING_THRESHOLD) * 100));

  return (
    <div className="fixed inset-0 z-50 overflow-hidden" role="dialog" aria-modal="true" aria-labelledby="cart-title">
      {/* Backdrop overlay */}
      <div
        className="fixed inset-0 bg-stone-900/60 backdrop-blur-xs transition-opacity duration-300"
        onClick={closeDrawer}
        aria-hidden="true"
      />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-stone-50 shadow-2xl flex flex-col border-l border-stone-200">
          {/* Header */}
          <div className="p-5 border-b border-stone-200 bg-white flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <ShoppingBag className="w-5 h-5 text-stone-800" />
              <h2 id="cart-title" className="text-base font-semibold text-stone-900 tracking-tight">
                Shopping Bag
              </h2>
              <span className="text-xs text-stone-500 tabular-nums">
                ({totalItemCount} {totalItemCount === 1 ? 'item' : 'items'})
              </span>
            </div>
            <button
              onClick={closeDrawer}
              className="p-2 text-stone-400 hover:text-stone-700 hover:bg-stone-100 rounded-lg transition-colors"
              aria-label="Close cart drawer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Free Shipping Progress Meter */}
          <div className="px-5 py-3.5 bg-stone-100 border-b border-stone-200/80">
            <div className="flex items-center justify-between text-xs text-stone-700 mb-1.5">
              <span>
                {totals.freeShippingQualified ? (
                  <strong className="text-emerald-700 font-semibold">You've unlocked Free Standard Shipping!</strong>
                ) : (
                  <span>
                    Add <strong className="tabular-nums font-semibold">${totals.amountNeededForFreeShipping.toFixed(2)}</strong> more for Free Shipping
                  </span>
                )}
              </span>
              <span className="text-stone-500 tabular-nums font-medium">{progressPercent}%</span>
            </div>
            <div className="w-full bg-stone-200 rounded-full h-1.5 overflow-hidden">
              <div
                className={`h-full transition-all duration-300 rounded-full ${
                  totals.freeShippingQualified ? 'bg-emerald-600' : 'bg-stone-800'
                }`}
                style={{ width: `${progressPercent}%` }}
              />
            </div>
          </div>

          {/* Cart Item List */}
          <div className="flex-1 overflow-y-auto p-5 divide-y divide-stone-200">
            {items.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center py-12">
                <div className="w-16 h-16 rounded-full bg-stone-100 border border-stone-200 flex items-center justify-center text-stone-400 mb-4">
                  <ShoppingBag className="w-8 h-8 stroke-1" />
                </div>
                <h3 className="text-base font-semibold text-stone-900 mb-1">Your bag is empty</h3>
                <p className="text-sm text-stone-500 max-w-xs mb-6">
                  Explore our curated collection of architectural home goods and lifestyle essentials.
                </p>
                <button
                  onClick={closeDrawer}
                  className="px-5 py-2.5 bg-stone-900 text-stone-50 text-xs font-semibold uppercase tracking-wider rounded-lg hover:bg-stone-800 transition-colors"
                >
                  Explore Catalog
                </button>
              </div>
            ) : (
              items.map((item) => {
                const imgUrl = item.product.images?.[0] || '/src/assets/images/lumina_leather_tote_1792496777297.jpg';
                return (
                  <div key={`${item.product._id}_${item.selectedVariant || ''}`} className="py-4 first:pt-0 last:pb-0 flex gap-4">
                    {/* Thumbnail */}
                    <div className="w-20 h-20 bg-stone-100 rounded-lg overflow-hidden shrink-0 border border-stone-200/60 relative">
                      <img
                        src={imgUrl}
                        alt={item.product.title}
                        className="w-full h-full object-cover"
                        onError={(e) => {
                          // Styled fallback
                          (e.target as HTMLElement).style.display = 'none';
                        }}
                      />
                    </div>

                    {/* Details */}
                    <div className="flex-1 min-w-0 flex flex-col justify-between">
                      <div>
                        <div className="flex items-start justify-between gap-2">
                          <div>
                            <span className="text-[11px] font-medium tracking-wide uppercase text-stone-400 block">
                              {item.product.category}
                            </span>
                            <h4 className="text-sm font-semibold text-stone-900 truncate leading-snug">
                              {item.product.title}
                            </h4>
                          </div>
                          <span className="text-sm font-semibold text-stone-900 tabular-nums shrink-0">
                            ${(item.product.price * item.quantity).toFixed(2)}
                          </span>
                        </div>
                        {item.selectedVariant && (
                          <span className="text-xs text-stone-500 mt-0.5 block">
                            Variant: {item.selectedVariant}
                          </span>
                        )}
                      </div>

                      {/* Stepper & Remove */}
                      <div className="flex items-center justify-between mt-3">
                        <div className="flex items-center border border-stone-200 rounded-md bg-white">
                          <button
                            onClick={() => updateQuantity(item.product._id, item.quantity - 1, item.selectedVariant)}
                            className="p-1.5 text-stone-500 hover:text-stone-900 hover:bg-stone-50 rounded-l transition-colors"
                            aria-label={`Decrease quantity of ${item.product.title}`}
                          >
                            <Minus className="w-3.5 h-3.5" />
                          </button>
                          <span className="w-8 text-center text-xs font-semibold tabular-nums text-stone-800">
                            {item.quantity}
                          </span>
                          <button
                            onClick={() => updateQuantity(item.product._id, item.quantity + 1, item.selectedVariant)}
                            disabled={item.quantity >= item.product.stock}
                            className="p-1.5 text-stone-500 hover:text-stone-900 hover:bg-stone-50 rounded-r transition-colors disabled:opacity-30 disabled:cursor-not-allowed"
                            aria-label={`Increase quantity of ${item.product.title}`}
                          >
                            <Plus className="w-3.5 h-3.5" />
                          </button>
                        </div>

                        <button
                          onClick={() => removeFromCart(item.product._id, item.selectedVariant)}
                          className="text-stone-400 hover:text-rose-600 p-1.5 transition-colors"
                          aria-label={`Remove ${item.product.title} from cart`}
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>

          {/* Footer & Checkout Area */}
          {items.length > 0 && (
            <div className="p-5 border-t border-stone-200 bg-white">
              {/* Promo Code Input */}
              <div className="mb-4">
                {promoCode ? (
                  <div className="flex items-center justify-between p-2.5 bg-emerald-50 border border-emerald-200 rounded-lg text-xs text-emerald-800">
                    <div className="flex items-center gap-1.5">
                      <Tag className="w-3.5 h-3.5 text-emerald-600" />
                      <span className="font-semibold">{promoCode}</span>
                      <span>({totals.discount > 0 ? `-$${totals.discount.toFixed(2)}` : 'Active'})</span>
                    </div>
                    <button
                      onClick={removePromoCode}
                      className="text-emerald-700 hover:text-emerald-900 font-medium underline transition-colors"
                    >
                      Remove
                    </button>
                  </div>
                ) : (
                  <form onSubmit={handleApplyCode} className="flex gap-2">
                    <input
                      type="text"
                      placeholder="Promo code (e.g. WELCOME10)"
                      value={inputCode}
                      onChange={(e) => setInputCode(e.target.value)}
                      className="flex-1 px-3 py-2 bg-stone-50 border border-stone-200 rounded-lg text-xs focus:outline-none focus:border-stone-800 uppercase tracking-wide placeholder:normal-case"
                    />
                    <button
                      type="submit"
                      disabled={isApplyingCode || !inputCode.trim()}
                      className="px-3.5 py-2 bg-stone-200 text-stone-800 hover:bg-stone-300 text-xs font-semibold rounded-lg transition-colors disabled:opacity-50"
                    >
                      Apply
                    </button>
                  </form>
                )}
              </div>

              {/* Price Breakdown */}
              <div className="space-y-1.5 text-xs text-stone-600 border-t border-stone-100 pt-3 mb-4">
                <div className="flex justify-between">
                  <span>Subtotal</span>
                  <span className="tabular-nums font-medium text-stone-900">${totals.subtotal.toFixed(2)}</span>
                </div>
                {totals.discount > 0 && (
                  <div className="flex justify-between text-emerald-700 font-medium">
                    <span>Discount</span>
                    <span className="tabular-nums">-${totals.discount.toFixed(2)}</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span>Estimated Shipping</span>
                  <span className="tabular-nums font-medium text-stone-900">
                    {totals.shipping === 0 ? 'Free' : `$${totals.shipping.toFixed(2)}`}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>Estimated Tax (8.5%)</span>
                  <span className="tabular-nums font-medium text-stone-900">${totals.tax.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-sm font-bold text-stone-900 pt-2 border-t border-stone-200">
                  <span>Estimated Total</span>
                  <span className="tabular-nums text-base">${totals.total.toFixed(2)}</span>
                </div>
              </div>

              {/* Secure Checkout CTA */}
              <button
                onClick={() => {
                  closeDrawer();
                  onCheckout();
                }}
                className="w-full py-3.5 px-4 bg-stone-900 hover:bg-stone-800 text-stone-50 font-medium text-sm rounded-lg flex items-center justify-center gap-2 shadow-sm transition-colors"
              >
                <span>Proceed to Checkout</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <div className="mt-3 flex items-center justify-center gap-2 text-[11px] text-stone-400">
                <ShieldCheck className="w-3.5 h-3.5 text-stone-500" />
                <span>256-Bit SSL Encrypted & NoSQL Secured</span>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
