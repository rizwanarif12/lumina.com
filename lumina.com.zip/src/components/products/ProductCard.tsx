import React from 'react';
import { ShoppingBag, Star } from 'lucide-react';
import type { Product } from '../../types/index.ts';
import { useCart } from '../../context/CartContext.tsx';

interface ProductCardProps {
  product: Product;
  onSelect: (product: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product, onSelect }) => {
  const { addToCart } = useCart();
  const primaryImage = product.images?.[0] || '/src/assets/images/lumina_leather_tote_1792496777297.jpg';

  const handleQuickAdd = (e: React.MouseEvent) => {
    e.stopPropagation();
    addToCart(product, 1);
  };

  const isLowStock = product.stock > 0 && product.stock <= 5;
  const isOutOfStock = product.stock <= 0;

  return (
    <div
      onClick={() => onSelect(product)}
      className="group relative bg-white border border-stone-200/80 rounded-xl overflow-hidden hover:shadow-lg transition-all duration-300 flex flex-col cursor-pointer hover:-translate-y-0.5"
    >
      {/* Product Image Frame */}
      <div className="relative aspect-4/3 w-full bg-stone-100 overflow-hidden">
        <img
          src={primaryImage}
          alt={product.title}
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover object-center group-hover:scale-103 transition-transform duration-500"
          onError={(e) => {
            (e.target as HTMLElement).style.display = 'none';
          }}
        />

        {/* Fallback container if image is hidden */}
        <div className="absolute inset-0 -z-10 flex flex-col items-center justify-center p-4 bg-stone-100 text-stone-400">
          <ShoppingBag className="w-8 h-8 stroke-1 mb-1" />
          <span className="text-xs">{product.title}</span>
        </div>

        {/* Quick Add Overlay on Desktop Hover */}
        <div className="absolute bottom-3 inset-x-3 opacity-0 group-hover:opacity-100 transition-opacity duration-200 hidden sm:block">
          <button
            onClick={handleQuickAdd}
            disabled={isOutOfStock}
            className="w-full py-2.5 px-4 bg-white/95 backdrop-blur-xs hover:bg-stone-900 hover:text-white text-stone-900 text-xs font-semibold rounded-lg shadow-md transition-colors flex items-center justify-center gap-1.5 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <ShoppingBag className="w-3.5 h-3.5" />
            <span>{isOutOfStock ? 'Sold Out' : 'Quick Add to Bag'}</span>
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="p-4 flex-1 flex flex-col justify-between">
        <div>
          {/* Metadata row with clean text separators */}
          <div className="flex items-center gap-2 text-xs text-stone-500 mb-1">
            <span className="uppercase tracking-wider text-[11px] font-medium text-stone-400">
              {product.category}
            </span>
            <span aria-hidden="true">·</span>
            {isOutOfStock ? (
              <span className="text-rose-600 font-medium">Sold Out</span>
            ) : isLowStock ? (
              <span className="text-amber-700 font-medium">Only {product.stock} left</span>
            ) : (
              <span className="text-stone-500">In Stock</span>
            )}
          </div>

          <h3 className="text-sm font-semibold text-stone-900 group-hover:text-stone-700 transition-colors line-clamp-1 mb-1">
            {product.title}
          </h3>

          <p className="text-xs text-stone-500 line-clamp-2 leading-relaxed mb-3">
            {product.subtitle || product.description}
          </p>
        </div>

        {/* Price & Rating Row */}
        <div className="pt-2 border-t border-stone-100 flex items-center justify-between">
          <div className="flex items-baseline gap-2">
            <span className="text-sm font-bold text-stone-900 tabular-nums">
              ${product.price.toFixed(2)}
            </span>
            {product.compareAtPrice && product.compareAtPrice > product.price && (
              <span className="text-xs text-stone-400 line-through tabular-nums">
                ${product.compareAtPrice.toFixed(2)}
              </span>
            )}
          </div>

          <div className="flex items-center gap-1 text-xs text-stone-600">
            <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
            <span className="font-semibold tabular-nums">{product.rating.toFixed(1)}</span>
            <span className="text-stone-400 text-[11px]">({product.reviewCount})</span>
          </div>
        </div>

        {/* Mobile Quick Add Button */}
        <button
          onClick={handleQuickAdd}
          disabled={isOutOfStock}
          className="mt-3 w-full py-2 bg-stone-900 text-stone-50 text-xs font-semibold rounded-lg sm:hidden flex items-center justify-center gap-1.5 active:bg-stone-800 disabled:opacity-40"
        >
          <ShoppingBag className="w-3.5 h-3.5" />
          <span>{isOutOfStock ? 'Sold Out' : 'Add to Bag'}</span>
        </button>
      </div>
    </div>
  );
};
