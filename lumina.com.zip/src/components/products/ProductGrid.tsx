import React from 'react';
import type { Product } from '../../types/index.ts';
import { ProductCard } from './ProductCard.tsx';
import { ShoppingBag } from 'lucide-react';

interface ProductGridProps {
  products: Product[];
  onSelectProduct: (product: Product) => void;
  isLoading?: boolean;
}

export const ProductGrid: React.FC<ProductGridProps> = ({
  products,
  onSelectProduct,
  isLoading,
}) => {
  if (isLoading) {
    return (
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
        {[1, 2, 3, 4, 5, 6].map((n) => (
          <div key={n} className="bg-white border border-stone-200/60 rounded-xl overflow-hidden animate-pulse">
            <div className="aspect-4/3 bg-stone-200" />
            <div className="p-4 space-y-3">
              <div className="h-3 bg-stone-200 rounded w-1/3" />
              <div className="h-4 bg-stone-200 rounded w-2/3" />
              <div className="h-3 bg-stone-200 rounded w-full" />
              <div className="h-4 bg-stone-200 rounded w-1/4 pt-2" />
            </div>
          </div>
        ))}
      </div>
    );
  }

  if (products.length === 0) {
    return (
      <div className="py-16 text-center bg-white border border-stone-200 rounded-xl p-8 max-w-lg mx-auto">
        <div className="w-12 h-12 bg-stone-100 rounded-full flex items-center justify-center mx-auto mb-3 text-stone-400">
          <ShoppingBag className="w-6 h-6 stroke-1" />
        </div>
        <h3 className="text-base font-semibold text-stone-900 mb-1">No products match your criteria</h3>
        <p className="text-xs text-stone-500 mb-4">
          Try clearing your search terms or selecting a different category from the navigation.
        </p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
      {products.map((product) => (
        <ProductCard
          key={product._id}
          product={product}
          onSelect={onSelectProduct}
        />
      ))}
    </div>
  );
};
