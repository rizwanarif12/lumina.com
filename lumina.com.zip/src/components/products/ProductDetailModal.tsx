import React, { useState } from 'react';
import { X, Star, ShoppingBag, ShieldCheck, Truck, RotateCcw, Plus, Minus } from 'lucide-react';
import type { Product } from '../../types/index.ts';
import { useCart } from '../../context/CartContext.tsx';

interface ProductDetailModalProps {
  product: Product | null;
  isOpen: boolean;
  onClose: () => void;
}

export const ProductDetailModal: React.FC<ProductDetailModalProps> = ({
  product,
  isOpen,
  onClose,
}) => {
  const { addToCart } = useCart();
  const [quantity, setQuantity] = useState(1);
  const [selectedImage, setSelectedImage] = useState(0);

  if (!isOpen || !product) return null;

  const handleAddToCart = () => {
    addToCart(product, quantity);
    onClose();
  };

  const images = product.images?.length > 0
    ? product.images
    : ['/src/assets/images/lumina_leather_tote_1792496777297.jpg'];

  const isOutOfStock = product.stock <= 0;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto" role="dialog" aria-modal="true" aria-labelledby="modal-headline">
      {/* Backdrop */}
      <div className="fixed inset-0 bg-stone-900/60 backdrop-blur-xs transition-opacity" onClick={onClose} aria-hidden="true" />

      {/* Centered modal container */}
      <div className="relative z-10 flex items-center justify-center min-h-screen p-4 pointer-events-none">
        <div className="pointer-events-auto w-full max-w-4xl bg-white rounded-2xl text-left overflow-hidden shadow-2xl border border-stone-200">
          <div className="absolute top-4 right-4 z-10">
            <button
              onClick={onClose}
              className="p-2 bg-white/80 hover:bg-white text-stone-600 hover:text-stone-900 rounded-full shadow-sm backdrop-blur-xs transition-colors"
              aria-label="Close modal"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2">
            {/* Gallery Column */}
            <div className="p-6 md:p-8 bg-stone-100 flex flex-col justify-center">
              <div className="aspect-4/3 w-full bg-white rounded-xl overflow-hidden shadow-sm relative">
                <img
                  src={images[selectedImage] || images[0]}
                  alt={product.title}
                  className="w-full h-full object-cover"
                />
              </div>

              {images.length > 1 && (
                <div className="flex gap-2 mt-4">
                  {images.map((img, idx) => (
                    <button
                      key={idx}
                      onClick={() => setSelectedImage(idx)}
                      className={`w-16 h-16 rounded-lg overflow-hidden border-2 transition-all ${
                        selectedImage === idx ? 'border-stone-900' : 'border-transparent opacity-60 hover:opacity-100'
                      }`}
                    >
                      <img src={img} alt={`Thumbnail ${idx + 1}`} className="w-full h-full object-cover" />
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Contiguous Purchase Module */}
            <div className="p-6 md:p-8 flex flex-col justify-between">
              <div>
                {/* Meta info */}
                <div className="flex items-center gap-2 text-xs text-stone-500 mb-2">
                  <span className="uppercase tracking-wider font-semibold text-stone-600">
                    {product.category}
                  </span>
                  <span aria-hidden="true">·</span>
                  <div className="flex items-center gap-1 text-stone-700">
                    <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                    <span className="font-semibold tabular-nums">{product.rating.toFixed(1)}</span>
                    <span className="text-stone-400">({product.reviewCount} reviews)</span>
                  </div>
                </div>

                <h2 id="modal-headline" className="text-xl md:text-2xl font-bold text-stone-900 mb-1 tracking-tight">
                  {product.title}
                </h2>

                {product.subtitle && (
                  <p className="text-sm text-stone-600 font-medium mb-3">
                    {product.subtitle}
                  </p>
                )}

                {/* Price */}
                <div className="flex items-baseline gap-3 mb-4">
                  <span className="text-2xl font-bold text-stone-900 tabular-nums">
                    ${product.price.toFixed(2)}
                  </span>
                  {product.compareAtPrice && product.compareAtPrice > product.price && (
                    <span className="text-sm text-stone-400 line-through tabular-nums">
                      ${product.compareAtPrice.toFixed(2)}
                    </span>
                  )}
                  {isOutOfStock ? (
                    <span className="text-xs font-semibold text-rose-600 bg-rose-50 px-2 py-0.5 rounded">
                      Out of Stock
                    </span>
                  ) : product.stock <= 5 ? (
                    <span className="text-xs font-semibold text-amber-700 bg-amber-50 px-2 py-0.5 rounded">
                      Low Stock: {product.stock} left
                    </span>
                  ) : (
                    <span className="text-xs font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded">
                      In Stock ({product.stock} units)
                    </span>
                  )}
                </div>

                <p className="text-xs md:text-sm text-stone-600 leading-relaxed mb-6">
                  {product.description}
                </p>

                {/* Specifications table */}
                {product.specs && Object.keys(product.specs).length > 0 && (
                  <div className="border border-stone-200 rounded-lg p-3 bg-stone-50 mb-6 text-xs divide-y divide-stone-200/60">
                    <span className="font-semibold text-stone-900 block pb-2">Technical Specifications</span>
                    {Object.entries(product.specs).map(([specKey, specVal]) => (
                      <div key={specKey} className="py-1.5 flex justify-between text-stone-600">
                        <span className="text-stone-500">{specKey}</span>
                        <span className="font-medium text-stone-900">{specVal}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Purchase Action Box */}
              <div className="space-y-4 pt-4 border-t border-stone-200">
                <div className="flex items-center gap-4">
                  <div className="flex items-center border border-stone-300 rounded-lg bg-stone-50">
                    <button
                      onClick={() => setQuantity(q => Math.max(1, q - 1))}
                      disabled={quantity <= 1}
                      className="p-2.5 text-stone-600 hover:text-stone-900 transition-colors disabled:opacity-30"
                      aria-label="Decrease quantity"
                    >
                      <Minus className="w-4 h-4" />
                    </button>
                    <span className="w-10 text-center text-sm font-semibold tabular-nums text-stone-900">
                      {quantity}
                    </span>
                    <button
                      onClick={() => setQuantity(q => Math.min(product.stock, q + 1))}
                      disabled={quantity >= product.stock}
                      className="p-2.5 text-stone-600 hover:text-stone-900 transition-colors disabled:opacity-30"
                      aria-label="Increase quantity"
                    >
                      <Plus className="w-4 h-4" />
                    </button>
                  </div>

                  <button
                    onClick={handleAddToCart}
                    disabled={isOutOfStock}
                    className="flex-1 py-3 px-6 bg-stone-900 text-stone-50 hover:bg-stone-800 text-xs font-semibold uppercase tracking-wider rounded-lg transition-colors flex items-center justify-center gap-2 shadow-sm disabled:opacity-40 disabled:cursor-not-allowed"
                  >
                    <ShoppingBag className="w-4 h-4" />
                    <span>{isOutOfStock ? 'Sold Out' : `Add to Bag · $${(product.price * quantity).toFixed(2)}`}</span>
                  </button>
                </div>

                {/* Trust Badges */}
                <div className="grid grid-cols-3 gap-2 text-[11px] text-stone-500 pt-2 border-t border-stone-100">
                  <div className="flex items-center gap-1.5">
                    <Truck className="w-3.5 h-3.5 text-stone-600 shrink-0" />
                    <span>Free ship $150+</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <RotateCcw className="w-3.5 h-3.5 text-stone-600 shrink-0" />
                    <span>30-Day Returns</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <ShieldCheck className="w-3.5 h-3.5 text-stone-600 shrink-0" />
                    <span>2-Yr Warranty</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
