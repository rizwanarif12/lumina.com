export interface PriceCalculationItem {
  price: number;
  quantity: number;
}

export const FREE_SHIPPING_THRESHOLD = 150;
export const STANDARD_SHIPPING_RATE = 12;
export const EXPRESS_SHIPPING_RATE = 28;
export const TAX_RATE = 0.085; // 8.5% sales tax

export const DISCOUNT_CODES: Record<string, number> = {
  WELCOME10: 0.10, // 10% off
  LUMINA20: 0.20,  // 20% off
  FREESHIP: 1.00,  // Free shipping promo
};

export function calculateSubtotal(items: PriceCalculationItem[]): number {
  if (!items || items.length === 0) return 0;
  const subtotal = items.reduce((acc, item) => {
    const qty = Math.max(0, Math.floor(item.quantity || 0));
    const price = Math.max(0, item.price || 0);
    return acc + qty * price;
  }, 0);
  return Number(subtotal.toFixed(2));
}

export function calculateShipping(
  subtotal: number,
  method: 'standard' | 'express' = 'standard',
  promoCode?: string
): number {
  if (subtotal <= 0) return 0;
  if (promoCode?.toUpperCase() === 'FREESHIP') return 0;

  if (method === 'express') {
    return EXPRESS_SHIPPING_RATE;
  }

  return subtotal >= FREE_SHIPPING_THRESHOLD ? 0 : STANDARD_SHIPPING_RATE;
}

export function calculateDiscount(subtotal: number, promoCode?: string): number {
  if (!promoCode || subtotal <= 0) return 0;
  const code = promoCode.toUpperCase().trim();
  if (code === 'FREESHIP') return 0; // handled in shipping
  const rate = DISCOUNT_CODES[code];
  if (!rate) return 0;
  return Number((subtotal * rate).toFixed(2));
}

export function calculateTax(taxableAmount: number): number {
  if (taxableAmount <= 0) return 0;
  return Number((taxableAmount * TAX_RATE).toFixed(2));
}

export function calculateCartTotals(
  items: PriceCalculationItem[],
  method: 'standard' | 'express' = 'standard',
  promoCode?: string
) {
  const subtotal = calculateSubtotal(items);
  const discount = calculateDiscount(subtotal, promoCode);
  const discountedSubtotal = Math.max(0, subtotal - discount);
  const shipping = calculateShipping(subtotal, method, promoCode);
  const tax = calculateTax(discountedSubtotal);
  const total = Number((discountedSubtotal + shipping + tax).toFixed(2));

  const freeShippingQualified = subtotal >= FREE_SHIPPING_THRESHOLD;
  const amountNeededForFreeShipping = freeShippingQualified
    ? 0
    : Number((FREE_SHIPPING_THRESHOLD - subtotal).toFixed(2));

  return {
    subtotal,
    discount,
    shipping,
    tax,
    total,
    freeShippingQualified,
    amountNeededForFreeShipping,
  };
}

export function validateInventory(
  currentStock: number,
  requestedQuantity: number
): { valid: boolean; available: number; message?: string } {
  const qty = Math.max(0, Math.floor(requestedQuantity));
  if (currentStock <= 0) {
    return { valid: false, available: 0, message: 'Item is currently out of stock' };
  }
  if (qty > currentStock) {
    return {
      valid: false,
      available: currentStock,
      message: `Only ${currentStock} units available in stock`,
    };
  }
  return { valid: true, available: currentStock };
}
