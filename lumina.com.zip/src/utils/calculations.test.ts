import test from 'node:test';
import assert from 'node:assert/strict';
import {
  calculateSubtotal,
  calculateShipping,
  calculateDiscount,
  calculateTax,
  calculateCartTotals,
  validateInventory,
  FREE_SHIPPING_THRESHOLD,
  STANDARD_SHIPPING_RATE,
  EXPRESS_SHIPPING_RATE,
} from './calculations.ts';

test('calculateSubtotal sums item prices multiplied by quantity', () => {
  const items = [
    { price: 45, quantity: 2 },
    { price: 120, quantity: 1 },
  ];
  assert.equal(calculateSubtotal(items), 210);
});

test('calculateSubtotal handles empty or invalid cart items', () => {
  assert.equal(calculateSubtotal([]), 0);
  assert.equal(calculateSubtotal([{ price: -10, quantity: 2 }]), 0);
});

test('calculateShipping waives shipping when subtotal reaches free threshold', () => {
  assert.equal(calculateShipping(50, 'standard'), STANDARD_SHIPPING_RATE);
  assert.equal(calculateShipping(FREE_SHIPPING_THRESHOLD, 'standard'), 0);
  assert.equal(calculateShipping(200, 'standard'), 0);
});

test('calculateShipping respects express shipping selection', () => {
  assert.equal(calculateShipping(200, 'express'), EXPRESS_SHIPPING_RATE);
});

test('calculateShipping waives shipping for FREESHIP promo code', () => {
  assert.equal(calculateShipping(50, 'standard', 'FREESHIP'), 0);
});

test('calculateDiscount applies correct percentage for valid coupon codes', () => {
  assert.equal(calculateDiscount(100, 'WELCOME10'), 10);
  assert.equal(calculateDiscount(100, 'LUMINA20'), 20);
  assert.equal(calculateDiscount(100, 'INVALID_CODE'), 0);
});

test('calculateTax applies 8.5% rate to taxable subtotal', () => {
  assert.equal(calculateTax(100), 8.5);
  assert.equal(calculateTax(0), 0);
});

test('calculateCartTotals computes consistent totals with discounts and shipping', () => {
  const items = [
    { price: 100, quantity: 1 },
  ];
  const totals = calculateCartTotals(items, 'standard', 'WELCOME10');
  // subtotal: 100
  // discount: 10 (100 * 0.10)
  // discounted subtotal: 90
  // shipping: 12 (since 100 < 150)
  // tax: 90 * 0.085 = 7.65
  // total: 90 + 12 + 7.65 = 109.65
  assert.equal(totals.subtotal, 100);
  assert.equal(totals.discount, 10);
  assert.equal(totals.shipping, 12);
  assert.equal(totals.tax, 7.65);
  assert.equal(totals.total, 109.65);
  assert.equal(totals.freeShippingQualified, false);
  assert.equal(totals.amountNeededForFreeShipping, 50);
});

test('validateInventory correctly evaluates stock limits', () => {
  assert.deepEqual(validateInventory(5, 3), { valid: true, available: 5 });
  assert.equal(validateInventory(5, 10).valid, false);
  assert.equal(validateInventory(0, 1).valid, false);
});
