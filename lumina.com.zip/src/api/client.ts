import type { Product, User, Order, ApiResponse, AuthResponse } from '../types/index.ts';

const TOKEN_KEY = 'lumina_auth_token';

export function getStoredToken(): string | null {
  return localStorage.getItem(TOKEN_KEY);
}

export function setStoredToken(token: string): void {
  localStorage.setItem(TOKEN_KEY, token);
}

export function clearStoredToken(): void {
  localStorage.removeItem(TOKEN_KEY);
}

async function request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const headers = new Headers(options.headers || {});
  headers.set('Content-Type', 'application/json');

  const token = getStoredToken();
  if (token) {
    headers.set('Authorization', `Bearer ${token}`);
  }

  const response = await fetch(endpoint, {
    ...options,
    headers,
  });

  const data = await response.json().catch(() => ({
    success: false,
    error: 'Failed to parse server response.',
  }));

  if (!response.ok) {
    throw new Error(data.error || data.message || `Request failed with status ${response.status}`);
  }

  return data;
}

export const api = {
  // Auth
  register: (body: { name: string; email: string; password: string; role?: string }) =>
    request<ApiResponse<AuthResponse>>('/api/auth/register', {
      method: 'POST',
      body: JSON.stringify(body),
    }),

  login: (body: { email: string; password: string }) =>
    request<ApiResponse<AuthResponse>>('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify(body),
    }),

  getProfile: () => request<ApiResponse<User>>('/api/auth/me'),

  updateProfile: (body: { name?: string; address?: any }) =>
    request<ApiResponse<User>>('/api/auth/profile', {
      method: 'PUT',
      body: JSON.stringify(body),
    }),

  // Products
  getProducts: (params?: {
    category?: string;
    search?: string;
    minPrice?: number;
    maxPrice?: number;
    sort?: string;
    featured?: boolean;
    page?: number;
    limit?: number;
  }) => {
    const searchParams = new URLSearchParams();
    if (params) {
      Object.entries(params).forEach(([k, v]) => {
        if (v !== undefined && v !== '') searchParams.append(k, String(v));
      });
    }
    const query = searchParams.toString();
    return request<ApiResponse<Product[]>>(`/api/products${query ? `?${query}` : ''}`);
  },

  getProduct: (id: string) => request<ApiResponse<Product>>(`/api/products/${id}`),

  getCategories: () => request<ApiResponse<Array<{ name: string; count: number }>>>('/api/products/categories'),

  // Admin Products
  createProduct: (productData: Partial<Product>) =>
    request<ApiResponse<Product>>('/api/admin/products', {
      method: 'POST',
      body: JSON.stringify(productData),
    }),

  updateProduct: (id: string, productData: Partial<Product>) =>
    request<ApiResponse<Product>>(`/api/admin/products/${id}`, {
      method: 'PUT',
      body: JSON.stringify(productData),
    }),

  deleteProduct: (id: string) =>
    request<ApiResponse<void>>(`/api/admin/products/${id}`, {
      method: 'DELETE',
    }),

  // Orders
  createOrder: (orderData: {
    items: any[];
    shippingAddress: any;
    shippingMethod?: string;
    paymentMethod?: string;
    promoCode?: string;
  }) =>
    request<ApiResponse<Order>>('/api/orders', {
      method: 'POST',
      body: JSON.stringify(orderData),
    }),

  getMyOrders: () => request<ApiResponse<Order[]>>('/api/orders/my'),

  // Admin Orders
  getAllOrders: () => request<ApiResponse<Order[]> & { count: number }>('/api/admin/orders'),

  updateOrderStatus: (id: string, status: string) =>
    request<ApiResponse<Order>>(`/api/admin/orders/${id}/status`, {
      method: 'PATCH',
      body: JSON.stringify({ status }),
    }),
};
