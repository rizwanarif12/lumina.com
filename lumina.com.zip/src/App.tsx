import React, { useState, useEffect } from 'react';
import { NotificationProvider } from './context/NotificationContext.tsx';
import { AuthProvider, useAuth } from './context/AuthContext.tsx';
import { CartProvider, useCart } from './context/CartContext.tsx';
import { Navbar } from './components/layout/Navbar.tsx';
import { Footer } from './components/layout/Footer.tsx';
import { MobileNav } from './components/layout/MobileNav.tsx';
import { CartDrawer } from './components/cart/CartDrawer.tsx';
import { ProductFilters } from './components/products/ProductFilters.tsx';
import { ProductGrid } from './components/products/ProductGrid.tsx';
import { ProductDetailModal } from './components/products/ProductDetailModal.tsx';
import { CheckoutModal } from './components/checkout/CheckoutModal.tsx';
import { OrderConfirmationModal } from './components/checkout/OrderConfirmationModal.tsx';
import { AuthModal } from './components/auth/AuthModal.tsx';
import { AdminCatalogManager } from './components/admin/AdminCatalogManager.tsx';
import { AdminOrdersView } from './components/admin/AdminOrdersView.tsx';
import { Pagination } from './components/products/Pagination.tsx';
import { api } from './api/client.ts';
import type { Product, Order } from './types/index.ts';
import { ArrowDown, Luggage, Sparkles, Compass, ShieldCheck, ShoppingBag, Eye } from 'lucide-react';

function StoreApp() {
  const [activeView, setActiveView] = useState<'store' | 'admin'>('store');
  const [adminTab, setAdminTab] = useState<'products' | 'orders'>('products');

  // Products and Catalog State (1,000 items with pagination)
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Array<{ name: string; count: number }>>([]);
  const [selectedCategory, setSelectedCategory] = useState('All Items');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState('featured');
  const [isLoadingProducts, setIsLoadingProducts] = useState(true);

  // Pagination state
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(24);
  const [totalItems, setTotalItems] = useState(1000);
  const [totalPages, setTotalPages] = useState(42);

  // Modals state
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isDetailOpen, setIsDetailOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [confirmedOrder, setConfirmedOrder] = useState<Order | null>(null);
  const [isConfirmationOpen, setIsConfirmationOpen] = useState(false);

  const { isAdmin, isAuthenticated, quickLogin } = useAuth();
  const { openDrawer } = useCart();

  const loadCatalogData = async () => {
    try {
      setIsLoadingProducts(true);
      const [prodRes, catRes] = await Promise.all([
        api.getProducts({
          category: selectedCategory === 'All Items' ? undefined : selectedCategory,
          search: searchQuery,
          sort: sortBy,
          page: currentPage,
          limit: itemsPerPage,
        }),
        api.getCategories(),
      ]);

      if (prodRes.success && prodRes.data) {
        setProducts(prodRes.data);
        if (prodRes.total !== undefined) setTotalItems(prodRes.total);
        if (prodRes.totalPages !== undefined) setTotalPages(prodRes.totalPages);
      }
      if (catRes.success && catRes.data) {
        setCategories(catRes.data);
      }
    } catch (err) {
      console.error('Failed to load products:', err);
    } finally {
      setIsLoadingProducts(false);
    }
  };

  // Reset to page 1 when filtering or searching
  useEffect(() => {
    setCurrentPage(1);
  }, [selectedCategory, searchQuery, sortBy, itemsPerPage]);

  useEffect(() => {
    loadCatalogData();
  }, [selectedCategory, searchQuery, sortBy, currentPage, itemsPerPage]);

  const handleSelectProduct = (product: Product) => {
    setSelectedProduct(product);
    setIsDetailOpen(true);
  };

  const handleOrderSuccess = (order: Order) => {
    setConfirmedOrder(order);
    setIsConfirmationOpen(true);
    loadCatalogData(); // refresh stock numbers
  };

  return (
    <div className="min-h-screen flex flex-col bg-stone-50 text-stone-900">
      {/* Top Bar Contract Navigation */}
      <Navbar
        activeView={activeView}
        setActiveView={setActiveView}
      />

      {/* Main View Router */}
      {activeView === 'admin' ? (
        <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="mb-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-stone-200 pb-4">
            <div>
              <h1 className="text-xl font-bold text-stone-900 tracking-tight">Admin Operations Suite</h1>
              <p className="text-xs text-stone-500 mt-0.5">
                Full-stack inventory control across {totalItems.toLocaleString()} items and MongoDB document store.
              </p>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setAdminTab('products')}
                className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
                  adminTab === 'products'
                    ? 'bg-stone-900 text-stone-50'
                    : 'bg-white border border-stone-200 text-stone-700 hover:bg-stone-50'
                }`}
              >
                Catalog Management
              </button>
              <button
                onClick={() => setAdminTab('orders')}
                className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
                  adminTab === 'orders'
                    ? 'bg-stone-900 text-stone-50'
                    : 'bg-white border border-stone-200 text-stone-700 hover:bg-stone-50'
                }`}
              >
                Orders & Shipments
              </button>
            </div>
          </div>

          {adminTab === 'products' ? (
            <AdminCatalogManager
              products={products}
              onRefresh={loadCatalogData}
            />
          ) : (
            <AdminOrdersView />
          )}
        </main>
      ) : (
        <main className="flex-1">
          {/* Storefront Hero Section */}
          <section className="relative overflow-hidden bg-stone-100 border-b border-stone-200">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-20">
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
                {/* Hero Text */}
                <div className="lg:col-span-5 space-y-6">
                  <div className="text-xs uppercase tracking-widest font-semibold text-stone-500 flex items-center gap-2">
                    <span>Atelier & Archives</span>
                    <span aria-hidden="true">·</span>
                    <span>1,000+ Curated Relics & Luggage</span>
                  </div>

                  <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-stone-900 tracking-tight text-balance leading-[1.12]">
                    Handmade bags, vintage trolley luggage, and antique artistry.
                  </h1>

                  <p className="text-sm sm:text-base text-stone-600 leading-relaxed max-w-lg">
                    Explore our expansive archive of 1,000 authenticated handcrafted leather bags, silent-spinner trolley cases, and museum-grade antique artifacts preserved across European and global studios.
                  </p>

                  <div className="flex flex-wrap items-center gap-3 pt-2">
                    <a
                      href="#catalog"
                      className="px-6 py-3.5 bg-stone-900 hover:bg-stone-800 text-stone-50 text-xs font-semibold uppercase tracking-wider rounded-lg transition-colors flex items-center gap-2 shadow-sm"
                    >
                      <span>Explore 1,000 Items</span>
                      <ArrowDown className="w-3.5 h-3.5" />
                    </a>
                    {!isAuthenticated && (
                      <button
                        onClick={() => quickLogin('customer')}
                        className="px-5 py-3.5 bg-white border border-stone-300 hover:bg-stone-50 text-stone-800 text-xs font-semibold rounded-lg transition-colors"
                      >
                        Try Demo Account
                      </button>
                    )}
                  </div>
                </div>

                {/* Hero Showcase Dual Visual */}
                <div className="lg:col-span-7 grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Card 1: Handcrafted Trolley Luggage */}
                  <div className="relative aspect-4/3 rounded-2xl overflow-hidden shadow-xl border border-stone-200/80 bg-stone-200 group">
                    <img
                      src="/src/assets/images/artisan_trolley_luggage_1792528198811.jpg"
                      alt="Handcrafted Leather Trolley Luggage"
                      className="w-full h-full object-cover group-hover:scale-102 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-stone-950/70 via-transparent to-transparent" />
                    <div className="absolute bottom-3 left-3 right-3 text-white text-xs">
                      <span className="font-semibold block text-sm">Artisan Trolley Luggage</span>
                      <span className="text-stone-300 text-[11px]">Italian Vachetta · Telescopic Brass</span>
                    </div>
                  </div>

                  {/* Card 2: Antique Artistry Artifacts */}
                  <div className="relative aspect-4/3 rounded-2xl overflow-hidden shadow-xl border border-stone-200/80 bg-stone-200 group">
                    <img
                      src="/src/assets/images/antique_artistry_artifact_1792528199505.jpg"
                      alt="Antique Artistry Celestial Astrolabe & Inlay Chest"
                      className="w-full h-full object-cover group-hover:scale-102 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-stone-950/70 via-transparent to-transparent" />
                    <div className="absolute bottom-3 left-3 right-3 text-white text-xs">
                      <span className="font-semibold block text-sm">Antique Artistry Artifacts</span>
                      <span className="text-stone-300 text-[11px]">Celestial Astrolabes & Bone Inlay</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>

          {/* Three Pillar Categories */}
          <section id="featured-section" className="bg-white border-b border-stone-200/80 py-10">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <button
                  onClick={() => setSelectedCategory('Handmade Bags')}
                  className="p-5 rounded-xl bg-stone-50 border border-stone-200/70 hover:border-stone-400 text-left transition-all hover:-translate-y-0.5 cursor-pointer"
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[11px] uppercase font-bold text-stone-500">
                      380 Handcrafted Editions
                    </span>
                    <ShoppingBag className="w-4 h-4 text-stone-700" />
                  </div>
                  <h3 className="text-base font-bold text-stone-900 mb-1">Handmade Bags & Totes</h3>
                  <p className="text-xs text-stone-500 leading-relaxed">
                    Full-grain vegetable-tanned Italian Vachetta, organic woven raffia, bohemian embroidery, and wax-linen saddle stitching.
                  </p>
                </button>

                <button
                  onClick={() => setSelectedCategory('Trolley Bags & Travel')}
                  className="p-5 rounded-xl bg-stone-50 border border-stone-200/70 hover:border-stone-400 text-left transition-all hover:-translate-y-0.5 cursor-pointer"
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[11px] uppercase font-bold text-stone-500">
                      310 Travel Editions
                    </span>
                    <Luggage className="w-4 h-4 text-stone-700" />
                  </div>
                  <h3 className="text-base font-bold text-stone-900 mb-1">Trolley Luggage & Voyage</h3>
                  <p className="text-xs text-stone-500 leading-relaxed">
                    Heritage rolling trunks, brass telescopic handles, and silent Hinomoto ball-bearing spinners engineered for grand transcontinental travel.
                  </p>
                </button>

                <button
                  onClick={() => setSelectedCategory('Antique Artistry & Artifacts')}
                  className="p-5 rounded-xl bg-stone-50 border border-stone-200/70 hover:border-stone-400 text-left transition-all hover:-translate-y-0.5 cursor-pointer"
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[11px] uppercase font-bold text-stone-500">
                      310 Authenticated Relics
                    </span>
                    <Compass className="w-4 h-4 text-stone-700" />
                  </div>
                  <h3 className="text-base font-bold text-stone-900 mb-1">Antique Artistry Artifacts</h3>
                  <p className="text-xs text-stone-500 leading-relaxed">
                    Chiseled celestial astrolabes, camel bone inlay caskets, repoussé copper urns, and hand-carved temple teak panels.
                  </p>
                </button>
              </div>
            </div>
          </section>

          {/* Product Catalog Section with 1,000 Items */}
          <section id="catalog" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
            <div className="mb-6 flex flex-col sm:flex-row sm:items-end justify-between gap-4">
              <div>
                <h2 className="text-2xl font-bold text-stone-900 tracking-tight">Artisan Archive</h2>
                <p className="text-xs text-stone-500 mt-1">
                  1,000 handcrafted bags, trolley luggage, and historical antique artistry pieces.
                </p>
              </div>
              <div className="text-xs text-stone-500">
                MongoDB NoSQL Indexed · Real-time Inventory Reconciled
              </div>
            </div>

            {/* Filters & Search */}
            <ProductFilters
              categories={categories}
              selectedCategory={selectedCategory}
              onSelectCategory={setSelectedCategory}
              searchQuery={searchQuery}
              onSearchChange={setSearchQuery}
              sortBy={sortBy}
              onSortChange={setSortBy}
              totalProductsCount={totalItems}
            />

            {/* Product Grid */}
            <ProductGrid
              products={products}
              onSelectProduct={handleSelectProduct}
              isLoading={isLoadingProducts}
            />

            {/* Pagination Controls */}
            <Pagination
              currentPage={currentPage}
              totalPages={totalPages}
              totalItems={totalItems}
              itemsPerPage={itemsPerPage}
              onPageChange={setCurrentPage}
              onItemsPerPageChange={(limit) => {
                setItemsPerPage(limit);
                setCurrentPage(1);
              }}
            />
          </section>

          {/* Provenance & Craftsmanship Section */}
          <section id="craftsmanship" className="bg-stone-900 text-stone-100 py-16 sm:py-24">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
                <div className="space-y-4">
                  <div className="text-xs font-semibold uppercase tracking-widest text-stone-400">
                    Heritage Provenance
                  </div>
                  <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-white">
                    Centuries of virtuosity, preserved for collectors.
                  </h2>
                  <p className="text-xs sm:text-sm text-stone-300 leading-relaxed">
                    Our atelier partners with third-generation leather masters in Florence, nomadic bone-inlay carvers in Rajasthan, and brass instrument restorers in Istanbul. Every piece in our 1,000-item collection arrives with an individual Certificate of Artisan Provenance and lifetime durability guarantee.
                  </p>
                  <div className="pt-2 flex items-center gap-6 text-xs text-stone-400">
                    <div>
                      <strong className="block text-xl font-bold text-white tabular-nums">1,000+</strong>
                      <span>Cataloged items</span>
                    </div>
                    <div>
                      <strong className="block text-xl font-bold text-white tabular-nums">100%</strong>
                      <span>Inspected & authenticated</span>
                    </div>
                    <div>
                      <strong className="block text-xl font-bold text-white tabular-nums">Free</strong>
                      <span>Insured shipping over $150</span>
                    </div>
                  </div>
                </div>

                <div className="aspect-4/3 rounded-2xl overflow-hidden border border-stone-800 bg-stone-800">
                  <img
                    src="/src/assets/images/antique_artistry_artifact_1792528199505.jpg"
                    alt="Handcrafted Celestial Relic and Bone Inlay Chest"
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>
            </div>
          </section>
        </main>
      )}

      {/* Footer */}
      <Footer />

      {/* Mobile Bottom Navigation Bar */}
      <MobileNav
        activeView={activeView}
        setActiveView={setActiveView}
      />

      {/* Slide-out Cart Drawer */}
      <CartDrawer
        onCheckout={() => setIsCheckoutOpen(true)}
      />

      {/* Modals */}
      <ProductDetailModal
        product={selectedProduct}
        isOpen={isDetailOpen}
        onClose={() => setIsDetailOpen(false)}
      />

      <CheckoutModal
        isOpen={isCheckoutOpen}
        onClose={() => setIsCheckoutOpen(false)}
        onOrderSuccess={handleOrderSuccess}
      />

      <OrderConfirmationModal
        order={confirmedOrder}
        isOpen={isConfirmationOpen}
        onClose={() => setIsConfirmationOpen(false)}
      />

      <AuthModal />
    </div>
  );
}

export default function App() {
  return (
    <NotificationProvider>
      <AuthProvider>
        <CartProvider>
          <StoreApp />
        </CartProvider>
      </AuthProvider>
    </NotificationProvider>
  );
}
