import React, { createContext, useContext, useState, useEffect, useCallback, useMemo } from 'react';
import type { CartItem, Product, CartTotals } from '../types/index.ts';
import { calculateCartTotals, validateInventory } from '../utils/calculations.ts';
import { useNotification } from './NotificationContext.tsx';

const CART_STORAGE_KEY = 'lumina_cart_items_v1';
const PROMO_STORAGE_KEY = 'lumina_cart_promo_v1';

interface CartContextType {
  items: CartItem[];
  addToCart: (product: Product, quantity?: number, selectedVariant?: string) => boolean;
  removeFromCart: (productId: string, selectedVariant?: string) => void;
  updateQuantity: (productId: string, quantity: number, selectedVariant?: string) => boolean;
  clearCart: () => void;
  isDrawerOpen: boolean;
  openDrawer: () => void;
  closeDrawer: () => void;
  toggleDrawer: () => void;
  promoCode: string;
  applyPromoCode: (code: string) => boolean;
  removePromoCode: () => void;
  shippingMethod: 'standard' | 'express';
  setShippingMethod: (method: 'standard' | 'express') => void;
  totals: CartTotals;
  totalItemCount: number;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export const CartProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [items, setItems] = useState<CartItem[]>(() => {
    try {
      const stored = localStorage.getItem(CART_STORAGE_KEY);
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  });

  const [promoCode, setPromoCode] = useState<string>(() => {
    try {
      return localStorage.getItem(PROMO_STORAGE_KEY) || '';
    } catch {
      return '';
    }
  });

  const [shippingMethod, setShippingMethod] = useState<'standard' | 'express'>('standard');
  const [isDrawerOpen, setIsDrawerOpen] = useState<boolean>(false);
  const { success, error, info } = useNotification();

  // Save items to localStorage whenever they change
  useEffect(() => {
    try {
      localStorage.setItem(CART_STORAGE_KEY, JSON.stringify(items));
    } catch {
      // storage quota or disabled
    }
  }, [items]);

  // Save promo code to localStorage
  useEffect(() => {
    try {
      if (promoCode) {
        localStorage.setItem(PROMO_STORAGE_KEY, promoCode);
      } else {
        localStorage.removeItem(PROMO_STORAGE_KEY);
      }
    } catch {
      // ignore
    }
  }, [promoCode]);

  const totalItemCount = useMemo(() => {
    return items.reduce((sum, item) => sum + item.quantity, 0);
  }, [items]);

  const totals = useMemo(() => {
    const calculationItems = items.map(item => ({
      price: item.product.price,
      quantity: item.quantity,
    }));
    return calculateCartTotals(calculationItems, shippingMethod, promoCode);
  }, [items, shippingMethod, promoCode]);

  const openDrawer = useCallback(() => setIsDrawerOpen(true), []);
  const closeDrawer = useCallback(() => setIsDrawerOpen(false), []);
  const toggleDrawer = useCallback(() => setIsDrawerOpen(prev => !prev), []);

  const addToCart = useCallback(
    (product: Product, quantity = 1, selectedVariant?: string): boolean => {
      const existing = items.find(
        i => i.product._id === product._id && i.selectedVariant === selectedVariant
      );

      const targetQuantity = (existing ? existing.quantity : 0) + quantity;
      const check = validateInventory(product.stock, targetQuantity);

      if (!check.valid) {
        error('Stock Limit', `${check.message} for ${product.title}`);
        return false;
      }

      setItems(prev => {
        const index = prev.findIndex(
          i => i.product._id === product._id && i.selectedVariant === selectedVariant
        );
        if (index > -1) {
          const next = [...prev];
          next[index] = { ...next[index], quantity: targetQuantity };
          return next;
        } else {
          return [...prev, { product, quantity, selectedVariant }];
        }
      });

      success('Added to Bag', `${quantity}x ${product.title}`);
      setIsDrawerOpen(true);
      return true;
    },
    [items, success, error]
  );

  const updateQuantity = useCallback(
    (productId: string, quantity: number, selectedVariant?: string): boolean => {
      const target = items.find(
        i => i.product._id === productId && i.selectedVariant === selectedVariant
      );
      if (!target) return false;

      if (quantity <= 0) {
        setItems(prev =>
          prev.filter(i => !(i.product._id === productId && i.selectedVariant === selectedVariant))
        );
        info('Item Removed', `Removed ${target.product.title} from bag.`);
        return true;
      }

      const check = validateInventory(target.product.stock, quantity);
      if (!check.valid) {
        error('Stock Limit Reached', check.message);
        return false;
      }

      setItems(prev =>
        prev.map(item => {
          if (item.product._id === productId && item.selectedVariant === selectedVariant) {
            return { ...item, quantity };
          }
          return item;
        })
      );
      return true;
    },
    [items, info, error]
  );

  const removeFromCart = useCallback(
    (productId: string, selectedVariant?: string) => {
      const target = items.find(
        i => i.product._id === productId && i.selectedVariant === selectedVariant
      );
      setItems(prev =>
        prev.filter(i => !(i.product._id === productId && i.selectedVariant === selectedVariant))
      );
      if (target) {
        info('Removed from Bag', target.product.title);
      }
    },
    [items, info]
  );

  const clearCart = useCallback(() => {
    setItems([]);
    setPromoCode('');
  }, []);

  const applyPromoCode = useCallback(
    (code: string): boolean => {
      const clean = code.toUpperCase().trim();
      const validCodes = ['WELCOME10', 'LUMINA20', 'FREESHIP'];

      if (!validCodes.includes(clean)) {
        error('Invalid Code', 'The promo code entered is not valid or has expired.');
        return false;
      }

      setPromoCode(clean);
      if (clean === 'WELCOME10') success('Coupon Applied', '10% discount applied to your order.');
      if (clean === 'LUMINA20') success('Coupon Applied', '20% VIP discount applied to your order.');
      if (clean === 'FREESHIP') success('Coupon Applied', 'Free standard shipping unlocked.');
      return true;
    },
    [success, error]
  );

  const removePromoCode = useCallback(() => {
    setPromoCode('');
    info('Promo Code Removed', 'Discount removed.');
  }, [info]);

  const value: CartContextType = {
    items,
    addToCart,
    removeFromCart,
    updateQuantity,
    clearCart,
    isDrawerOpen,
    openDrawer,
    closeDrawer,
    toggleDrawer,
    promoCode,
    applyPromoCode,
    removePromoCode,
    shippingMethod,
    setShippingMethod,
    totals,
    totalItemCount,
  };

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
};

export function useCart(): CartContextType {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
}
