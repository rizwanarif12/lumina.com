import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import type { User } from '../types/index.ts';
import { api, getStoredToken, setStoredToken, clearStoredToken } from '../api/client.ts';
import { useNotification } from './NotificationContext.tsx';

interface AuthContextType {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
  isAdmin: boolean;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<boolean>;
  register: (name: string, email: string, password: string, role?: string) => Promise<boolean>;
  logout: () => void;
  quickLogin: (role: 'admin' | 'customer') => Promise<void>;
  isAuthModalOpen: boolean;
  authModalTab: 'login' | 'register';
  openAuthModal: (tab?: 'login' | 'register') => void;
  closeAuthModal: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(getStoredToken());
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState<boolean>(false);
  const [authModalTab, setAuthModalTab] = useState<'login' | 'register'>('login');
  const { success, error } = useNotification();

  // Load user session on mount
  useEffect(() => {
    async function initAuth() {
      const stored = getStoredToken();
      if (!stored) {
        setIsLoading(false);
        return;
      }
      try {
        const res = await api.getProfile();
        if (res.success && res.data) {
          setUser(res.data);
        } else {
          clearStoredToken();
          setToken(null);
        }
      } catch {
        clearStoredToken();
        setToken(null);
      } finally {
        setIsLoading(false);
      }
    }
    initAuth();
  }, []);

  const login = useCallback(async (email: string, password: string): Promise<boolean> => {
    try {
      const res = await api.login({ email, password });
      if (res.success && res.data) {
        setStoredToken(res.data.token);
        setToken(res.data.token);
        setUser(res.data.user);
        success(`Welcome back, ${res.data.user.name}`);
        setIsAuthModalOpen(false);
        return true;
      }
      return false;
    } catch (err: any) {
      error('Sign In Failed', err.message);
      return false;
    }
  }, [success, error]);

  const register = useCallback(async (name: string, email: string, password: string, role: string = 'customer'): Promise<boolean> => {
    try {
      const res = await api.register({ name, email, password, role });
      if (res.success && res.data) {
        setStoredToken(res.data.token);
        setToken(res.data.token);
        setUser(res.data.user);
        success('Account Created', `Welcome to Lumina, ${res.data.user.name}`);
        setIsAuthModalOpen(false);
        return true;
      }
      return false;
    } catch (err: any) {
      error('Registration Failed', err.message);
      return false;
    }
  }, [success, error]);

  const logout = useCallback(() => {
    clearStoredToken();
    setToken(null);
    setUser(null);
    success('Signed Out', 'You have been safely signed out.');
  }, [success]);

  const quickLogin = useCallback(async (role: 'admin' | 'customer') => {
    if (role === 'admin') {
      await login('admin@lumina.dev', 'AdminPassword123!');
    } else {
      await login('jane@example.com', 'CustomerPass123!');
    }
  }, [login]);

  const openAuthModal = useCallback((tab: 'login' | 'register' = 'login') => {
    setAuthModalTab(tab);
    setIsAuthModalOpen(true);
  }, []);

  const closeAuthModal = useCallback(() => {
    setIsAuthModalOpen(false);
  }, []);

  const value: AuthContextType = {
    user,
    token,
    isAuthenticated: !!user,
    isAdmin: user?.role === 'admin',
    isLoading,
    login,
    register,
    logout,
    quickLogin,
    isAuthModalOpen,
    authModalTab,
    openAuthModal,
    closeAuthModal,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export function useAuth(): AuthContextType {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
